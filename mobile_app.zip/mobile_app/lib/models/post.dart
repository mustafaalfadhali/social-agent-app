class SocialPost {
  final int id;
  final String caption;
  final String? mediaUrl;
  final String targetPlatforms;
  final String status;
  final String? resultLog;

  SocialPost({
    required this.id,
    required this.caption,
    this.mediaUrl,
    required this.targetPlatforms,
    required this.status,
    this.resultLog,
  });

  factory SocialPost.fromJson(Map<String, dynamic> json) {
    return SocialPost(
      id: json['id'],
      caption: json['caption'],
      mediaUrl: json['media_url'],
      targetPlatforms: json['target_platforms'],
      status: json['status'],
      resultLog: json['result_log'],
    );
  }
}
