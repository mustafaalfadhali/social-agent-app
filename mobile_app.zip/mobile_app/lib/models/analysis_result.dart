class AnalysisResult {
  final String platform;
  final String summary;
  final List<String> strengths;
  final List<String> recommendations;
  final List<String> bestPostingTimes;

  AnalysisResult({
    required this.platform,
    required this.summary,
    required this.strengths,
    required this.recommendations,
    required this.bestPostingTimes,
  });

  factory AnalysisResult.fromJson(Map<String, dynamic> json) {
    return AnalysisResult(
      platform: json['platform'] ?? '',
      summary: json['summary'] ?? '',
      strengths: List<String>.from(json['strengths'] ?? const []),
      recommendations: List<String>.from(json['recommendations'] ?? const []),
      bestPostingTimes:
          List<String>.from(json['best_posting_times'] ?? const []),
    );
  }
}
