class SocialAccount {
  final int id;
  final String platform; // "facebook_page" | "instagram_business"
  final String platformAccountId;
  final String? displayName;

  SocialAccount({
    required this.id,
    required this.platform,
    required this.platformAccountId,
    this.displayName,
  });

  factory SocialAccount.fromJson(Map<String, dynamic> json) {
    return SocialAccount(
      id: json['id'],
      platform: json['platform'],
      platformAccountId: json['platform_account_id'],
      displayName: json['display_name'],
    );
  }

  String get platformLabel =>
      platform == 'instagram_business' ? 'Instagram' : 'Facebook Page';
}
