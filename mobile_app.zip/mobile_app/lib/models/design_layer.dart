import 'dart:ui';

enum LayerType { text, shape, image }

enum ShapeKind { rectangle, circle }

/// One draggable/resizable/rotatable element on the poster canvas.
/// A single class covers all layer types (text/shape/image) - simpler than
/// a class hierarchy for a small editor like this, at the cost of a few
/// unused fields per instance.
class DesignLayer {
  DesignLayer({
    required this.id,
    required this.type,
    required this.position,
    required this.size,
    this.rotation = 0,
    this.text = 'Double-tap to edit',
    this.fontSize = 32,
    this.color = const Color(0xFFFFFFFF),
    this.bold = false,
    this.shapeKind = ShapeKind.rectangle,
    this.fillColor = const Color(0xFF4F46E5),
    this.imagePath,
  });

  final String id;
  final LayerType type;

  // Shared transform
  Offset position; // center of the layer, in canvas coordinates
  Size size;
  double rotation; // radians

  // Text-specific
  String text;
  double fontSize;
  Color color;
  bool bold;

  // Shape-specific
  ShapeKind shapeKind;
  Color fillColor;

  // Image-specific
  String? imagePath; // local file path (from gallery/camera)

  DesignLayer copyWith() => DesignLayer(
        id: id,
        type: type,
        position: position,
        size: size,
        rotation: rotation,
        text: text,
        fontSize: fontSize,
        color: color,
        bold: bold,
        shapeKind: shapeKind,
        fillColor: fillColor,
        imagePath: imagePath,
      );
}
