import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Thin wrapper around on-device speech recognition + text-to-speech.
///
/// Honest scope note, worth repeating in the UI too: this is **push-to-talk**
/// (tap the mic, speak, it stops on its own or you tap again) using the
/// phone's built-in speech recognizer - it is NOT an always-listening
/// "Hey Jarvis" wake word. A true always-on wake word needs a dedicated
/// engine (e.g. Porcupine) running as a foreground service, plus the
/// battery and privacy tradeoffs that come with continuous microphone
/// access. That's a meaningfully bigger feature than what's built here.
class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  bool _speechAvailable = false;

  Future<bool> init() async {
    _speechAvailable = await _speech.initialize();
    return _speechAvailable;
  }

  bool get isListening => _speech.isListening;

  Future<void> startListening({
    required void Function(String text, bool isFinal) onResult,
  }) async {
    if (!_speechAvailable) {
      final ok = await init();
      if (!ok) return;
    }
    await _speech.listen(
      onResult: (result) =>
          onResult(result.recognizedWords, result.finalResult),
    );
  }

  Future<void> stopListening() async {
    if (_speech.isListening) {
      await _speech.stop();
    }
  }

  Future<void> speak(String text) async {
    await _tts.setSpeechRate(0.48);
    await _tts.speak(text);
  }

  Future<void> stopSpeaking() async {
    await _tts.stop();
  }
}
