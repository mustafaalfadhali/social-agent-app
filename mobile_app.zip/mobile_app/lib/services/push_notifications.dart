import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'api_service.dart';

/// Push notifications (Firebase Cloud Messaging) for "your agent created a
/// draft while you were away."
///
/// Deliberately fails silently at every step: this app must keep working
/// exactly as before for anyone who hasn't set up a Firebase project yet.
/// There's no `firebase_options.dart` (the file `flutterfire configure`
/// normally generates) checked in, so `Firebase.initializeApp()` is called
/// WITHOUT an explicit `options:` argument - on Android this still works as
/// long as `android/app/google-services.json` is present (see the README's
/// "Push notifications" section), and if it isn't, initialization just
/// throws and we catch it here. Nothing about this class ever crashes the
/// app or blocks login/usage.
class PushNotifications {
  PushNotifications._();

  /// Call once, right after the user lands on the Command Center. Fire-and
  /// forget - don't await this from a build method.
  static Future<void> initAndRegister(ApiService api) async {
    try {
      await Firebase.initializeApp();

      final messaging = FirebaseMessaging.instance;
      await messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );

      final token = await messaging.getToken();
      if (token != null && token.isNotEmpty) {
        await api.updateDeviceToken(token);
      }

      // Keep the backend's copy fresh if Firebase rotates the token later.
      FirebaseMessaging.instance.onTokenRefresh.listen((newToken) {
        api.updateDeviceToken(newToken).catchError((_) {});
      });
    } catch (_) {
      // Firebase not configured yet (no google-services.json), or genuinely
      // offline, or any other setup issue - this feature is best-effort and
      // must never take the rest of the app down with it.
    }
  }
}
