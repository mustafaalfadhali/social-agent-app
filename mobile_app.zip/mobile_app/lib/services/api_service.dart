import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';

import 'token_storage.dart';
import '../models/social_account.dart';
import '../models/analysis_result.dart';
import '../models/post.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

/// All network calls to the backend live here. Change [baseUrl] to point at
/// your deployed backend (use 10.0.2.2 instead of localhost when testing on
/// the Android emulator).
class ApiService {
  ApiService({this.baseUrl = 'http://10.0.2.2:8000'});

  final String baseUrl;
  final TokenStorage _tokenStorage = TokenStorage();

  Future<Map<String, String>> _authHeaders() async {
    final token = await _tokenStorage.read();
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  void _throwIfError(http.Response resp) {
    if (resp.statusCode >= 400) {
      String detail = resp.body;
      try {
        detail = jsonDecode(resp.body)['detail']?.toString() ?? resp.body;
      } catch (_) {}
      throw ApiException(detail);
    }
  }

  // ---------- Auth ----------
  Future<void> register({
    required String email,
    required String password,
    String? fullName,
  }) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email,
        'password': password,
        'full_name': fullName,
      }),
    );
    _throwIfError(resp);
  }

  Future<void> login({required String email, required String password}) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/auth/login'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {'username': email, 'password': password},
    );
    _throwIfError(resp);
    final token = jsonDecode(resp.body)['access_token'] as String;
    await _tokenStorage.save(token);
  }

  Future<void> logout() => _tokenStorage.clear();

  Future<bool> isLoggedIn() async => (await _tokenStorage.read()) != null;

  // ---------- Meta connection ----------
  Future<String> getMetaConnectUrl() async {
    final resp = await http.get(
      Uri.parse('$baseUrl/meta/connect-url'),
      headers: await _authHeaders(),
    );
    _throwIfError(resp);
    return jsonDecode(resp.body)['url'] as String;
  }

  Future<List<SocialAccount>> completeMetaCallback({
    required String code,
    required String state,
  }) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/meta/callback?code=$code&state=$state'),
      headers: await _authHeaders(),
    );
    _throwIfError(resp);
    final list = jsonDecode(resp.body) as List;
    return list.map((e) => SocialAccount.fromJson(e)).toList();
  }

  Future<List<SocialAccount>> getConnectedAccounts() async {
    final resp = await http.get(
      Uri.parse('$baseUrl/meta'),
      headers: await _authHeaders(),
    );
    _throwIfError(resp);
    final list = jsonDecode(resp.body) as List;
    return list.map((e) => SocialAccount.fromJson(e)).toList();
  }

  // ---------- Analysis ----------
  Future<AnalysisResult> analyzeAccount(int socialAccountId) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/analysis'),
      headers: await _authHeaders(),
      body: jsonEncode({'social_account_id': socialAccountId}),
    );
    _throwIfError(resp);
    return AnalysisResult.fromJson(jsonDecode(resp.body));
  }

  // ---------- Posts ----------
  Future<SocialPost> createAndPublishPost({
    required String caption,
    String? mediaUrl,
    required List<String> targetPlatforms,
  }) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/posts'),
      headers: await _authHeaders(),
      body: jsonEncode({
        'caption': caption,
        'media_url': mediaUrl,
        'target_platforms': targetPlatforms,
      }),
    );
    _throwIfError(resp);
    return SocialPost.fromJson(jsonDecode(resp.body));
  }

  Future<List<SocialPost>> getPosts({String? status}) async {
    final uri = Uri.parse('$baseUrl/posts').replace(
      queryParameters: status != null ? {'status': status} : null,
    );
    final resp = await http.get(uri, headers: await _authHeaders());
    _throwIfError(resp);
    final list = jsonDecode(resp.body) as List;
    return list.map((e) => SocialPost.fromJson(e)).toList();
  }

  Future<SocialPost> approvePost(int postId) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/posts/$postId/approve'),
      headers: await _authHeaders(),
    );
    _throwIfError(resp);
    return SocialPost.fromJson(jsonDecode(resp.body));
  }

  Future<SocialPost> rejectPost(int postId, {String? reason}) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/posts/$postId/reject'),
      headers: await _authHeaders(),
      body: jsonEncode({'reason': reason}),
    );
    _throwIfError(resp);
    return SocialPost.fromJson(jsonDecode(resp.body));
  }

  // ---------- Autonomous agent ----------
  /// Triggers one agent cycle: it reviews accounts, decides on its own
  /// whether to draft a post, and returns its summary + tool call log.
  /// Never publishes directly - drafts always land in getPosts(status:
  /// 'pending_approval') for a human to approve/reject.
  Future<Map<String, dynamic>> runAgentCycle() async {
    final resp = await http.post(
      Uri.parse('$baseUrl/agent/run'),
      headers: await _authHeaders(),
    );
    _throwIfError(resp);
    return jsonDecode(resp.body) as Map<String, dynamic>;
  }

  /// History of past agent runs (manual taps AND unattended scheduled
  /// runs) - what the Command Center's activity feed reads from.
  Future<List<Map<String, dynamic>>> getAgentRuns() async {
    final resp = await http.get(
      Uri.parse('$baseUrl/agent/runs'),
      headers: await _authHeaders(),
    );
    _throwIfError(resp);
    return List<Map<String, dynamic>>.from(jsonDecode(resp.body) as List);
  }

  // ---------- Push notifications ----------
  /// Registers this device's FCM token with the backend so
  /// notify_user() (see push_notifications.dart / the backend's
  /// services/notifications.py) can reach it. Safe to call every app start -
  /// overwrites any previous token for this user.
  Future<void> updateDeviceToken(String token) async {
    final resp = await http.put(
      Uri.parse('$baseUrl/users/me/device-token'),
      headers: await _authHeaders(),
      body: jsonEncode({'token': token}),
    );
    _throwIfError(resp);
  }

  // ---------- AI content generation ----------
  /// Returns a list of {caption, hashtags} maps - 3 ready-to-use variations.
  Future<List<Map<String, dynamic>>> generatePostContent({
    required String topic,
    String platform = 'instagram_business',
    String tone = 'friendly and professional',
    String language = 'Arabic',
  }) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/content/generate-post'),
      headers: await _authHeaders(),
      body: jsonEncode({
        'topic': topic,
        'platform': platform,
        'tone': tone,
        'language': language,
      }),
    );
    _throwIfError(resp);
    final data = jsonDecode(resp.body);
    return List<Map<String, dynamic>>.from(data['variations'] as List);
  }

  // ---------- Media upload (for posters made in the in-app design editor) ----------
  Future<String> uploadMedia(String filePath) async {
    final token = await _tokenStorage.read();
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/media/upload'),
    );
    if (token != null) {
      request.headers['Authorization'] = 'Bearer $token';
    }

    final ext = filePath.split('.').last.toLowerCase();
    final contentType = switch (ext) {
      'png' => MediaType('image', 'png'),
      'jpg' || 'jpeg' => MediaType('image', 'jpeg'),
      'webp' => MediaType('image', 'webp'),
      _ => MediaType('application', 'octet-stream'),
    };
    request.files.add(
      await http.MultipartFile.fromPath('file', filePath, contentType: contentType),
    );

    final streamed = await request.send();
    final resp = await http.Response.fromStream(streamed);
    _throwIfError(resp);
    return jsonDecode(resp.body)['url'] as String;
  }
}
