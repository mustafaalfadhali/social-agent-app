import 'package:flutter/material.dart';

/// Dark-mode chart tokens taken verbatim from the dataviz skill's validated
/// reference palette (references/palette.md) - this app is dark-theme-only,
/// so only the dark column is used. These are pre-validated (CVD-safe
/// adjacent pairs, contrast-checked against the dark chart surface); if you
/// have your own brand's validated palette, swap the hex values here and
/// nowhere else.
class DataVizColors {
  DataVizColors._();

  // Chart chrome & ink
  static const Color chartSurface = Color(0xFF1A1A19);
  static const Color primaryInk = Color(0xFFFFFFFF);
  static const Color secondaryInk = Color(0xFFC3C2B7);
  static const Color mutedInk = Color(0xFF898781);
  static const Color gridline = Color(0xFF2C2C2A);
  static const Color baseline = Color(0xFF383835);

  // Sequential (blue) - magnitude only, one hue light->dark. Step 400 is
  // the mid-value step used for gauge fills; the track uses the gridline
  // token rather than a lighter step, per the "recessive track" convention.
  static const Color sequential400 = Color(0xFF3987E5);
  static const Color sequentialTrack = gridline;

  // Status palette (fixed - never themed, never used for series identity).
  // Always pair with an icon + label, never color alone.
  static const Color statusGood = Color(0xFF0CA30C);
  static const Color statusWarning = Color(0xFFFAB219);
  static const Color statusSerious = Color(0xFFEC835A);
  static const Color statusCritical = Color(0xFFD03B3B);
}
