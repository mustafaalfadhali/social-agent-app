import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../services/voice_service.dart';
import '../theme/dataviz_colors.dart';

enum VoiceSheetMode { full, topicOnly }

/// Push-to-talk bottom sheet.
///
/// - [VoiceSheetMode.full] (opened from the Command Center): can run the
///   agent right there and speak its summary back - the closest thing in
///   this app to "Hey Jarvis, check my pages."
/// - [VoiceSheetMode.topicOnly] (opened from the composer's mic button):
///   only captures a spoken topic and returns it via Navigator.pop, for
///   the caller to feed into AI copywriting.
class VoiceCommandSheet extends StatefulWidget {
  const VoiceCommandSheet({super.key, this.mode = VoiceSheetMode.full});

  final VoiceSheetMode mode;

  static Future<String?> show(
    BuildContext context, {
    VoiceSheetMode mode = VoiceSheetMode.full,
  }) {
    return showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: DataVizColors.chartSurface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => VoiceCommandSheet(mode: mode),
    );
  }

  @override
  State<VoiceCommandSheet> createState() => _VoiceCommandSheetState();
}

class _VoiceCommandSheetState extends State<VoiceCommandSheet> {
  final _voice = VoiceService();
  final _api = ApiService();

  bool _listening = false;
  bool _ready = false;
  bool _checkedReady = false;
  bool _running = false;
  String _transcript = '';
  String? _agentSummary;
  String? _error;

  @override
  void initState() {
    super.initState();
    _voice.init().then((ok) {
      if (!mounted) return;
      setState(() {
        _ready = ok;
        _checkedReady = true;
      });
    });
  }

  Future<void> _toggleListening() async {
    if (_listening) {
      await _voice.stopListening();
      if (mounted) setState(() => _listening = false);
      return;
    }
    if (!_ready) {
      setState(() => _error =
          'Speech recognition is not available on this device (check mic permission).');
      return;
    }
    setState(() {
      _transcript = '';
      _agentSummary = null;
      _error = null;
      _listening = true;
    });
    await _voice.startListening(
      onResult: (text, isFinal) {
        if (!mounted) return;
        setState(() => _transcript = text);
        if (isFinal) setState(() => _listening = false);
      },
    );
  }

  Future<void> _runAgent() async {
    setState(() {
      _running = true;
      _error = null;
    });
    try {
      final result = await _api.runAgentCycle();
      final summary = result['summary']?.toString() ?? 'Done.';
      setState(() => _agentSummary = summary);
      await _voice.speak(summary);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  @override
  void dispose() {
    _voice.stopListening();
    _voice.stopSpeaking();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 24,
        right: 24,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onTap: _toggleListening,
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _listening
                    ? DataVizColors.statusCritical.withOpacity(0.2)
                    : Theme.of(context).colorScheme.primary.withOpacity(0.15),
                border: Border.all(
                  color: _listening
                      ? DataVizColors.statusCritical
                      : Theme.of(context).colorScheme.primary,
                  width: 2,
                ),
              ),
              child: Icon(
                _listening ? Icons.stop : Icons.mic,
                size: 30,
                color: _listening
                    ? DataVizColors.statusCritical
                    : Theme.of(context).colorScheme.primary,
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            _listening ? 'Listening… tap to stop' : 'Tap to speak',
            style: const TextStyle(color: DataVizColors.mutedInk, fontSize: 13),
          ),
          if (_checkedReady && !_ready)
            const Padding(
              padding: EdgeInsets.only(top: 10),
              child: Text(
                'Push-to-talk only - not an always-listening "Hey Jarvis" wake word.',
                textAlign: TextAlign.center,
                style: TextStyle(color: DataVizColors.mutedInk, fontSize: 11),
              ),
            ),
          const SizedBox(height: 18),
          if (_transcript.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.black26,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(_transcript,
                  style: const TextStyle(color: DataVizColors.primaryInk)),
            ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!, style: const TextStyle(color: DataVizColors.statusCritical)),
          ],
          if (_agentSummary != null) ...[
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: DataVizColors.statusGood.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: DataVizColors.statusGood.withOpacity(0.4)),
              ),
              child: Text(_agentSummary!,
                  style: const TextStyle(color: DataVizColors.primaryInk)),
            ),
          ],
          if (_transcript.isNotEmpty && !_listening) ...[
            const SizedBox(height: 18),
            if (widget.mode == VoiceSheetMode.full)
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _running ? null : _runAgent,
                  icon: _running
                      ? const SizedBox(
                          height: 16,
                          width: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.smart_toy_outlined),
                  label: const Text('Run agent now'),
                ),
              ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => Navigator.of(context).pop(_transcript),
                icon: const Icon(Icons.edit_note),
                label: const Text('Use as post topic'),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
