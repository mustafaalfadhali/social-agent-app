import 'dart:math' as math;
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';

import '../theme/dataviz_colors.dart';

/// A single-hue radial dial for one magnitude value (0.0-1.0) - the "Jarvis
/// HUD" visual, built on the dataviz skill's sequential-color rule: one hue,
/// never a rainbow standing in for a single number. The value's fill uses
/// [DataVizColors.sequential400]; only the label carries meaning beyond the
/// arc, per "text wears text tokens, never the series color."
class RadialGauge extends StatelessWidget {
  const RadialGauge({
    super.key,
    required this.value,
    required this.centerText,
    required this.label,
    this.centerSubtext,
    this.color = DataVizColors.sequential400,
    this.trackColor = DataVizColors.sequentialTrack,
    this.size = 180,
  });

  final double value; // 0..1
  final String centerText;
  final String label;
  final String? centerSubtext;
  final Color color;
  final Color trackColor;
  final double size;

  @override
  Widget build(BuildContext context) {
    final clamped = value.clamp(0.0, 1.0);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: size,
          height: size,
          child: CustomPaint(
            painter: _GaugePainter(value: clamped, color: color, trackColor: trackColor),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    centerText,
                    style: const TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w700,
                      color: DataVizColors.primaryInk,
                      fontFeatures: [FontFeature.tabularFigures()],
                    ),
                  ),
                  if (centerSubtext != null)
                    Text(
                      centerSubtext!,
                      style: const TextStyle(fontSize: 12, color: DataVizColors.mutedInk),
                    ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          label,
          style: const TextStyle(color: DataVizColors.secondaryInk, fontSize: 13),
        ),
      ],
    );
  }
}

class _GaugePainter extends CustomPainter {
  _GaugePainter({required this.value, required this.color, required this.trackColor});

  final double value;
  final Color color;
  final Color trackColor;

  // A ~270 degree dial with a gap at the bottom - reads as a HUD instrument
  // rather than a full pie, and leaves room for the center readout.
  static const double _startAngle = -math.pi / 2 - (math.pi * 0.75);
  static const double _sweepTotal = math.pi * 1.5;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2 - 10;

    final trackPaint = Paint()
      ..color = trackColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      _startAngle,
      _sweepTotal,
      false,
      trackPaint,
    );

    if (value > 0) {
      final valuePaint = Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10
        ..strokeCap = StrokeCap.round;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        _startAngle,
        _sweepTotal * value,
        false,
        valuePaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _GaugePainter oldDelegate) =>
      oldDelegate.value != value ||
      oldDelegate.color != color ||
      oldDelegate.trackColor != trackColor;
}
