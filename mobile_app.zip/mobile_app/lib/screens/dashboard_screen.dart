import 'package:flutter/material.dart';

import '../models/social_account.dart';
import '../services/api_service.dart';
import 'connect_account_screen.dart';
import 'analysis_screen.dart';
import 'composer_screen.dart';
import 'agent_screen.dart';
import 'login_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _api = ApiService();
  late Future<List<SocialAccount>> _accountsFuture;

  @override
  void initState() {
    super.initState();
    _accountsFuture = _api.getConnectedAccounts();
  }

  void _refresh() {
    setState(() => _accountsFuture = _api.getConnectedAccounts());
  }

  Future<void> _connectAccount() async {
    final result = await Navigator.of(context).push<List<SocialAccount>>(
      MaterialPageRoute(
        builder: (_) => const ConnectAccountScreen(
          redirectUriPrefix: 'http://localhost:8000/meta/callback',
        ),
      ),
    );
    if (result != null) _refresh();
  }

  Future<void> _logout() async {
    await _api.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Pages'),
        actions: [
          IconButton(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const AgentScreen()),
            ),
            icon: const Icon(Icons.smart_toy_outlined),
            tooltip: 'AI Agent',
          ),
          IconButton(
            onPressed: _logout,
            icon: const Icon(Icons.logout),
            tooltip: 'Log out',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => _refresh(),
        child: FutureBuilder<List<SocialAccount>>(
          future: _accountsFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            final accounts = snapshot.data ?? [];
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Card(
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.12),
                  child: ListTile(
                    leading: const Icon(Icons.smart_toy_outlined),
                    title: const Text('AI Agent'),
                    subtitle: const Text('Autonomous review + drafts awaiting approval'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const AgentScreen()),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                if (accounts.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 60),
                    child: Column(
                      children: [
                        const Icon(Icons.link_off, size: 40, color: Colors.white38),
                        const SizedBox(height: 12),
                        const Text(
                          'No pages connected yet.',
                          style: TextStyle(color: Colors.white60),
                        ),
                      ],
                    ),
                  )
                else
                  ...accounts.map(
                    (a) => Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        leading: CircleAvatar(
                          backgroundColor: a.platform == 'instagram_business'
                              ? Colors.pink.withOpacity(0.2)
                              : Colors.blue.withOpacity(0.2),
                          child: Icon(
                            a.platform == 'instagram_business'
                                ? Icons.camera_alt_outlined
                                : Icons.facebook,
                            size: 20,
                          ),
                        ),
                        title: Text(a.displayName ?? a.platformLabel),
                        subtitle: Text(a.platformLabel),
                        trailing: TextButton(
                          onPressed: () => Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => AnalysisScreen(account: a),
                            ),
                          ),
                          child: const Text('Analyze'),
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: _connectAccount,
                  icon: const Icon(Icons.add_link),
                  label: const Text('Connect Facebook / Instagram'),
                ),
                if (accounts.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ComposerScreen(accounts: accounts),
                      ),
                    ),
                    icon: const Icon(Icons.edit_note),
                    label: const Text('Create a post'),
                  ),
                ],
              ],
            );
          },
        ),
      ),
    );
  }
}
