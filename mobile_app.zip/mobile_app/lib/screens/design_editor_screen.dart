import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../models/design_layer.dart';

const List<Color> _kSwatches = [
  Colors.white,
  Colors.black,
  Color(0xFFEF4444), // red
  Color(0xFFF97316), // orange
  Color(0xFFF59E0B), // amber
  Color(0xFF22C55E), // green
  Color(0xFF14B8A6), // teal
  Color(0xFF3B82F6), // blue
  Color(0xFF4F46E5), // indigo
  Color(0xFFA855F7), // purple
  Color(0xFFEC4899), // pink
];

/// A small but genuinely functional Canva-style poster editor: add text,
/// shape and image layers to a square canvas, drag/pinch to move, resize
/// and rotate each one, tweak color/font, then export to a PNG file.
///
/// Returns the exported file's local path via Navigator.pop when the user
/// taps "Done" — the caller (ComposerScreen) is responsible for uploading
/// it via ApiService.uploadMedia() to get a public URL Meta can publish.
class DesignEditorScreen extends StatefulWidget {
  const DesignEditorScreen({super.key});

  @override
  State<DesignEditorScreen> createState() => _DesignEditorScreenState();
}

class _DesignEditorScreenState extends State<DesignEditorScreen> {
  final GlobalKey _canvasKey = GlobalKey();
  final List<DesignLayer> _layers = [];
  final ImagePicker _imagePicker = ImagePicker();

  String? _selectedId;
  Color _backgroundColor = const Color(0xFF1F2937);
  bool _exporting = false;
  int _idCounter = 0;

  // Gesture bookkeeping for the currently-manipulated layer.
  Size _baseSize = Size.zero;
  double _baseRotation = 0;

  DesignLayer? get _selectedLayer {
    if (_selectedId == null) return null;
    for (final l in _layers) {
      if (l.id == _selectedId) return l;
    }
    return null;
  }

  String _nextId() => 'layer_${_idCounter++}';

  void _addTextLayer() {
    setState(() {
      final layer = DesignLayer(
        id: _nextId(),
        type: LayerType.text,
        position: const Offset(150, 150),
        size: const Size(220, 80),
        text: 'Your text here',
      );
      _layers.add(layer);
      _selectedId = layer.id;
    });
  }

  void _addShapeLayer(ShapeKind kind) {
    setState(() {
      final layer = DesignLayer(
        id: _nextId(),
        type: LayerType.shape,
        position: const Offset(150, 150),
        size: const Size(140, 140),
        shapeKind: kind,
      );
      _layers.add(layer);
      _selectedId = layer.id;
    });
  }

  Future<void> _addImageLayer() async {
    final picked = await _imagePicker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;
    setState(() {
      final layer = DesignLayer(
        id: _nextId(),
        type: LayerType.image,
        position: const Offset(150, 150),
        size: const Size(220, 220),
        imagePath: picked.path,
      );
      _layers.add(layer);
      _selectedId = layer.id;
    });
  }

  void _bringToFront(DesignLayer layer) {
    setState(() {
      _layers.remove(layer);
      _layers.add(layer);
    });
  }

  void _duplicateSelected() {
    final layer = _selectedLayer;
    if (layer == null) return;
    setState(() {
      final copy = layer.copyWith();
      final newLayer = DesignLayer(
        id: _nextId(),
        type: copy.type,
        position: copy.position + const Offset(16, 16),
        size: copy.size,
        rotation: copy.rotation,
        text: copy.text,
        fontSize: copy.fontSize,
        color: copy.color,
        bold: copy.bold,
        shapeKind: copy.shapeKind,
        fillColor: copy.fillColor,
        imagePath: copy.imagePath,
      );
      _layers.add(newLayer);
      _selectedId = newLayer.id;
    });
  }

  void _deleteSelected() {
    final layer = _selectedLayer;
    if (layer == null) return;
    setState(() {
      _layers.remove(layer);
      _selectedId = null;
    });
  }

  Future<void> _editText(DesignLayer layer) async {
    final controller = TextEditingController(text: layer.text);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit text'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLines: 3,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (result != null) {
      setState(() => layer.text = result);
    }
  }

  Future<void> _export() async {
    setState(() => _exporting = true);
    try {
      final boundary = _canvasKey.currentContext!.findRenderObject()
          as RenderRepaintBoundary;
      final ui.Image image = await boundary.toImage(pixelRatio: 3.0);
      final ByteData? byteData =
          await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) throw Exception('Could not encode image');
      final Uint8List bytes = byteData.buffer.asUint8List();

      final dir = await getTemporaryDirectory();
      final file = File(
        '${dir.path}/poster_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      await file.writeAsBytes(bytes);

      if (!mounted) return;
      Navigator.of(context).pop(file.path);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Export failed: $e')));
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Design a poster'),
        actions: [
          IconButton(
            tooltip: 'Duplicate',
            onPressed: _selectedLayer == null ? null : _duplicateSelected,
            icon: const Icon(Icons.copy_outlined),
          ),
          IconButton(
            tooltip: 'Delete',
            onPressed: _selectedLayer == null ? null : _deleteSelected,
            icon: const Icon(Icons.delete_outline),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: FilledButton.icon(
              onPressed: _exporting ? null : _export,
              icon: _exporting
                  ? const SizedBox(
                      height: 16,
                      width: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.check, size: 18),
              label: const Text('Done'),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: GestureDetector(
                // Tapping empty canvas space deselects the current layer.
                onTap: () => setState(() => _selectedId = null),
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: RepaintBoundary(
                      key: _canvasKey,
                      child: ClipRect(
                        child: Container(
                          color: _backgroundColor,
                          child: Stack(
                            children: _layers.map(_buildLayer).toList(),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (_selectedLayer != null) _buildPropertiesPanel(_selectedLayer!),
          _buildToolbar(),
        ],
      ),
    );
  }

  Widget _buildLayer(DesignLayer layer) {
    final isSelected = layer.id == _selectedId;

    Widget content;
    switch (layer.type) {
      case LayerType.text:
        content = Center(
          child: Text(
            layer.text,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: layer.fontSize,
              color: layer.color,
              fontWeight: layer.bold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        );
        break;
      case LayerType.shape:
        content = Container(
          decoration: BoxDecoration(
            color: layer.fillColor,
            shape: layer.shapeKind == ShapeKind.circle
                ? BoxShape.circle
                : BoxShape.rectangle,
            borderRadius: layer.shapeKind == ShapeKind.rectangle
                ? BorderRadius.circular(12)
                : null,
          ),
        );
        break;
      case LayerType.image:
        content = layer.imagePath == null
            ? Container(
                color: Colors.white24,
                child: const Icon(Icons.image_outlined),
              )
            : ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(File(layer.imagePath!), fit: BoxFit.cover),
              );
        break;
    }

    return Positioned(
      left: layer.position.dx - layer.size.width / 2,
      top: layer.position.dy - layer.size.height / 2,
      width: layer.size.width,
      height: layer.size.height,
      child: GestureDetector(
        onTap: () => setState(() => _selectedId = layer.id),
        onDoubleTap:
            layer.type == LayerType.text ? () => _editText(layer) : null,
        onScaleStart: (_) {
          setState(() => _selectedId = layer.id);
          _baseSize = layer.size;
          _baseRotation = layer.rotation;
        },
        onScaleUpdate: (details) {
          setState(() {
            layer.position += details.focalPointDelta;
            if (details.pointerCount > 1) {
              layer.size = Size(
                (_baseSize.width * details.scale).clamp(24, 4000),
                (_baseSize.height * details.scale).clamp(24, 4000),
              );
              layer.rotation = _baseRotation + details.rotation;
            }
          });
        },
        child: Transform.rotate(
          angle: layer.rotation,
          child: Container(
            decoration: isSelected
                ? BoxDecoration(
                    border: Border.all(
                      color: Theme.of(context).colorScheme.primary,
                      width: 2,
                    ),
                  )
                : null,
            child: content,
          ),
        ),
      ),
    );
  }

  Widget _buildPropertiesPanel(DesignLayer layer) {
    return Container(
      color: Colors.black26,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (layer.type == LayerType.text) ...[
            Row(
              children: [
                const Icon(Icons.format_size, size: 18),
                Expanded(
                  child: Slider(
                    min: 12,
                    max: 96,
                    value: layer.fontSize.clamp(12, 96),
                    onChanged: (v) => setState(() => layer.fontSize = v),
                  ),
                ),
                IconButton(
                  icon: Icon(
                    Icons.format_bold,
                    color: layer.bold
                        ? Theme.of(context).colorScheme.primary
                        : null,
                  ),
                  onPressed: () => setState(() => layer.bold = !layer.bold),
                ),
              ],
            ),
            _colorRow(
              current: layer.color,
              onPick: (c) => setState(() => layer.color = c),
            ),
          ] else if (layer.type == LayerType.shape) ...[
            Row(
              children: [
                ChoiceChip(
                  label: const Text('Rectangle'),
                  selected: layer.shapeKind == ShapeKind.rectangle,
                  onSelected: (_) =>
                      setState(() => layer.shapeKind = ShapeKind.rectangle),
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: const Text('Circle'),
                  selected: layer.shapeKind == ShapeKind.circle,
                  onSelected: (_) =>
                      setState(() => layer.shapeKind = ShapeKind.circle),
                ),
              ],
            ),
            _colorRow(
              current: layer.fillColor,
              onPick: (c) => setState(() => layer.fillColor = c),
            ),
          ] else
            TextButton.icon(
              onPressed: () => _bringToFront(layer),
              icon: const Icon(Icons.flip_to_front),
              label: const Text('Bring to front'),
            ),
        ],
      ),
    );
  }

  Widget _colorRow({required Color current, required ValueChanged<Color> onPick}) {
    return SizedBox(
      height: 36,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: _kSwatches.map((c) {
          final selected = c.value == current.value;
          return GestureDetector(
            onTap: () => onPick(c),
            child: Container(
              margin: const EdgeInsets.only(right: 8),
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: c,
                shape: BoxShape.circle,
                border: Border.all(
                  color: selected ? Colors.white : Colors.white24,
                  width: selected ? 2.5 : 1,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: Colors.white12)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _toolButton(Icons.text_fields, 'Text', _addTextLayer),
            _toolButton(
              Icons.crop_square,
              'Rectangle',
              () => _addShapeLayer(ShapeKind.rectangle),
            ),
            _toolButton(
              Icons.circle_outlined,
              'Circle',
              () => _addShapeLayer(ShapeKind.circle),
            ),
            _toolButton(Icons.image_outlined, 'Image', _addImageLayer),
            _toolButton(Icons.palette_outlined, 'Background', () async {
              final picked = await showModalBottomSheet<Color>(
                context: context,
                builder: (context) => SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: _kSwatches
                          .map((c) => GestureDetector(
                                onTap: () => Navigator.pop(context, c),
                                child: CircleAvatar(backgroundColor: c, radius: 20),
                              ))
                          .toList(),
                    ),
                  ),
                ),
              );
              if (picked != null) {
                setState(() => _backgroundColor = picked);
              }
            }),
          ],
        ),
      ),
    );
  }

  Widget _toolButton(IconData icon, String label, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: OutlinedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 18),
        label: Text(label),
      ),
    );
  }
}
