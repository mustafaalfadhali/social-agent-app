import 'package:flutter/material.dart';

import '../models/post.dart';
import '../services/api_service.dart';

/// Where the *autonomous* part of the app lives, as opposed to the
/// composer (which is entirely user-driven, one click = one AI call).
/// "Run agent now" kicks off a real tool-use loop on the backend (see
/// backend/app/services/agent_runner.py) where Claude decides for itself
/// what to check and whether to draft a post - nothing here is a fixed
/// sequence of steps you clicked through. The only thing it can never do
/// on its own is publish: every draft it makes lands below, waiting for
/// you to Approve or Reject.
class AgentScreen extends StatefulWidget {
  const AgentScreen({super.key});

  @override
  State<AgentScreen> createState() => _AgentScreenState();
}

class _AgentScreenState extends State<AgentScreen> {
  final _api = ApiService();

  bool _running = false;
  Map<String, dynamic>? _lastRun;
  late Future<List<SocialPost>> _pendingFuture;

  @override
  void initState() {
    super.initState();
    _pendingFuture = _api.getPosts(status: 'pending_approval');
  }

  void _refreshPending() {
    setState(() => _pendingFuture = _api.getPosts(status: 'pending_approval'));
  }

  Future<void> _runAgent() async {
    setState(() {
      _running = true;
      _lastRun = null;
    });
    try {
      // The backend kicks the cycle off in the background and replies right
      // away (see backend/app/routers/agent.py) - a full cycle (several
      // Claude calls, up to 3 drafts) can easily take longer than
      // Cloudflare's fixed ~100s edge timeout, so we can't just await one
      // long request for the result anymore. Instead: remember what the
      // latest run was before we start, then poll until a new one shows up.
      final before = await _api.getAgentRuns();
      final beforeLatestId = before.isNotEmpty ? before.first['id'] : null;

      await _api.runAgentCycle();

      Map<String, dynamic>? newRun;
      const maxAttempts = 30; // ~2.5 min at 5s each - generous for a multi-draft cycle
      for (var attempt = 0; attempt < maxAttempts; attempt++) {
        await Future.delayed(const Duration(seconds: 5));
        final runs = await _api.getAgentRuns();
        if (runs.isNotEmpty && runs.first['id'] != beforeLatestId) {
          newRun = runs.first;
          break;
        }
      }

      if (newRun != null) {
        setState(() => _lastRun = newRun);
        _refreshPending();
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              "Still working in the background - pull to refresh in a bit."),
        ));
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Agent run failed: ${e.message}')));
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  Future<void> _approve(SocialPost post) async {
    try {
      await _api.approvePost(post.id);
      _refreshPending();
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Published.')));
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Approve failed: ${e.message}')));
    }
  }

  Future<void> _reject(SocialPost post) async {
    // Ask why (optional) - this is what the agent reads back via
    // get_recent_feedback on its next run, so a real reason here is what
    // actually makes it "learn" instead of just retrying blindly.
    final reason = await _askRejectReason();
    if (reason == false) return; // user cancelled the dialog entirely
    try {
      await _api.rejectPost(post.id, reason: reason == true ? null : reason as String?);
      _refreshPending();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Reject failed: ${e.message}')));
    }
  }

  /// Returns the typed reason (String), `true` for "skip, no reason", or
  /// `false` if the dialog was dismissed (meaning: don't reject at all).
  Future<dynamic> _askRejectReason() async {
    final controller = TextEditingController();
    return showDialog<dynamic>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reject this draft'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Why? (optional, but helps the agent improve)',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(
              controller.text.trim().isEmpty ? true : controller.text.trim(),
            ),
            child: const Text('Reject'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Agent')),
      body: RefreshIndicator(
        onRefresh: () async => _refreshPending(),
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.smart_toy_outlined,
                            color: Theme.of(context).colorScheme.primary),
                        const SizedBox(width: 8),
                        Text('Autonomous review',
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'The agent reviews your connected pages itself every '
                      '2 days, decides whether new posts are worth making '
                      'right now, and — if so — drafts up to 3 of them. It '
                      'can never publish on its own; anything it makes '
                      'shows up below (and sends you a notification) for '
                      'you to approve or reject.',
                      style: TextStyle(color: Colors.white60),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: _running ? null : _runAgent,
                      icon: _running
                          ? const SizedBox(
                              height: 16,
                              width: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.play_arrow),
                      label: Text(_running ? 'Thinking…' : 'Run agent now'),
                    ),
                    if (_lastRun != null) ...[
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.black26,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _lastRun!['summary']?.toString() ?? '',
                              style: const TextStyle(fontStyle: FontStyle.italic),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '${_lastRun!['turns']} step(s) · '
                              '${(_lastRun!['created_draft_ids'] as List?)?.length ?? 0} draft(s) created',
                              style: const TextStyle(fontSize: 12, color: Colors.white38),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text('Awaiting your approval',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            FutureBuilder<List<SocialPost>>(
              future: _pendingFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState != ConnectionState.done) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final drafts = snapshot.data ?? [];
                if (drafts.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Text('Nothing pending right now.',
                        style: TextStyle(color: Colors.white38)),
                  );
                }
                return Column(
                  children: drafts.map((post) {
                    final reasoning = (post.resultLog ?? '')
                        .replaceFirst('Agent reasoning: ', '');
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(post.caption),
                            if (reasoning.isNotEmpty) ...[
                              const SizedBox(height: 8),
                              Text(
                                'Why: $reasoning',
                                style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.white38,
                                    fontStyle: FontStyle.italic),
                              ),
                            ],
                            const SizedBox(height: 4),
                            Text(
                              'Target: ${post.targetPlatforms}',
                              style: const TextStyle(fontSize: 12, color: Colors.white38),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                OutlinedButton(
                                  onPressed: () => _reject(post),
                                  child: const Text('Reject'),
                                ),
                                const SizedBox(width: 8),
                                FilledButton(
                                  onPressed: () => _approve(post),
                                  child: const Text('Approve & publish'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
