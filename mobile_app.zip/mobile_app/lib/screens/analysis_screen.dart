import 'package:flutter/material.dart';

import '../models/social_account.dart';
import '../models/analysis_result.dart';
import '../services/api_service.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({super.key, required this.account});

  final SocialAccount account;

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  final _api = ApiService();
  late Future<AnalysisResult> _future;

  @override
  void initState() {
    super.initState();
    _future = _api.analyzeAccount(widget.account.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Analysis · ${widget.account.displayName ?? widget.account.platformLabel}'),
      ),
      body: FutureBuilder<AnalysisResult>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Claude is analyzing engagement data…'),
                ],
              ),
            );
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('${snapshot.error}', textAlign: TextAlign.center),
              ),
            );
          }
          final result = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              _SectionCard(
                icon: Icons.summarize_outlined,
                title: 'Summary',
                child: Text(result.summary),
              ),
              const SizedBox(height: 16),
              _SectionCard(
                icon: Icons.bolt_outlined,
                title: 'Strengths',
                child: _BulletList(items: result.strengths),
              ),
              const SizedBox(height: 16),
              _SectionCard(
                icon: Icons.lightbulb_outline,
                title: 'Recommendations',
                child: _BulletList(items: result.recommendations),
              ),
              const SizedBox(height: 16),
              _SectionCard(
                icon: Icons.schedule_outlined,
                title: 'Best posting times',
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: result.bestPostingTimes
                      .map((t) => Chip(label: Text(t)))
                      .toList(),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.icon, required this.title, required this.child});

  final IconData icon;
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 20, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                Text(title,
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}

class _BulletList extends StatelessWidget {
  const _BulletList({required this.items});
  final List<String> items;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items
          .map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('•  '),
                    Expanded(child: Text(item)),
                  ],
                ),
              ))
          .toList(),
    );
  }
}
