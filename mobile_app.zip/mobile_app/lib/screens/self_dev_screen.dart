import 'package:flutter/material.dart';

import '../services/api_service.dart';

/// The self-development agent's screen: a SEPARATE cycle from the content
/// agent (AgentScreen) - this one reads its OWN backend source code (and
/// may research the web for current best practices), and can propose AT
/// MOST one code change per run. It also runs automatically on a daily
/// schedule (see backend/app/services/scheduler.py) so it keeps improving
/// over time without anyone tapping anything.
///
/// The one rule that never changes, no matter what: it can NEVER write a
/// single byte to disk itself. Every proposal sits here as
/// "pending_approval" until you explicitly tap Approve or Reject below -
/// that tap is the only thing in the entire system that can turn a
/// proposal into a real code change.
class SelfDevScreen extends StatefulWidget {
  const SelfDevScreen({super.key});

  @override
  State<SelfDevScreen> createState() => _SelfDevScreenState();
}

class _SelfDevScreenState extends State<SelfDevScreen> {
  final _api = ApiService();

  bool _running = false;
  bool _busyId(int id) => _busyIds.contains(id);
  final Set<int> _busyIds = {};
  late Future<List<Map<String, dynamic>>> _proposalsFuture;

  @override
  void initState() {
    super.initState();
    _proposalsFuture = _api.getCodeProposals();
  }

  void _refresh() {
    setState(() => _proposalsFuture = _api.getCodeProposals());
  }

  Future<void> _runSelfDev() async {
    setState(() => _running = true);
    try {
      final before = await _api.getCodeProposals();
      final beforeLatestId = before.isNotEmpty ? before.first['id'] : null;

      await _api.runSelfDev();

      Map<String, dynamic>? newProposal;
      const maxAttempts = 30; // ~2.5 min at 5s each - it may research the web first
      for (var attempt = 0; attempt < maxAttempts; attempt++) {
        await Future.delayed(const Duration(seconds: 5));
        final proposals = await _api.getCodeProposals();
        if (proposals.isNotEmpty && proposals.first['id'] != beforeLatestId) {
          newProposal = proposals.first;
          break;
        }
      }

      if (!mounted) return;
      if (newProposal != null) {
        _refresh();
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Review finished - see below.'),
        ));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              "Still working in the background - pull to refresh in a bit."),
        ));
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Self-dev run failed: ${e.message}')));
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  Future<void> _approve(Map<String, dynamic> proposal) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Apply this change?'),
        content: Text(
          'This will write the change to ${proposal['file_path']} and '
          'restart the backend to load it (a few seconds of downtime). '
          'This cannot be undone automatically.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Apply'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _busyIds.add(proposal['id'] as int));
    try {
      await _api.approveCodeProposal(proposal['id'] as int);
      _refresh();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Applied - the backend is restarting now.'),
      ));
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Approve failed: ${e.message}')));
    } finally {
      if (mounted) setState(() => _busyIds.remove(proposal['id'] as int));
    }
  }

  Future<void> _reject(Map<String, dynamic> proposal) async {
    setState(() => _busyIds.add(proposal['id'] as int));
    try {
      await _api.rejectCodeProposal(proposal['id'] as int);
      _refresh();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Reject failed: ${e.message}')));
    } finally {
      if (mounted) setState(() => _busyIds.remove(proposal['id'] as int));
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'applied':
        return Colors.greenAccent;
      case 'rejected':
        return Colors.redAccent;
      case 'failed':
        return Colors.orangeAccent;
      default:
        return Colors.amberAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Self-Development Agent')),
      body: RefreshIndicator(
        onRefresh: () async => _refresh(),
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.auto_fix_high,
                            color: Theme.of(context).colorScheme.primary),
                        const SizedBox(width: 8),
                        Text('Continuous self-improvement',
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'This agent reads its own backend code (and can '
                      'research the web for current best practices), and '
                      'runs automatically once a day so it keeps getting '
                      'better over time. It can NEVER change a single line '
                      'on its own — every idea lands below as a proposal, '
                      'and only your explicit Approve makes it real.',
                      style: TextStyle(color: Colors.white60),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: _running ? null : _runSelfDev,
                      icon: _running
                          ? const SizedBox(
                              height: 16,
                              width: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.play_arrow),
                      label: Text(_running ? 'Reviewing…' : 'Review now'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text('Proposals', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            FutureBuilder<List<Map<String, dynamic>>>(
              future: _proposalsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState != ConnectionState.done) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final proposals = snapshot.data ?? [];
                if (proposals.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Text(
                        'No proposals yet - tap "Review now" or wait for '
                        'tomorrow\'s automatic run.',
                        style: TextStyle(color: Colors.white38)),
                  );
                }
                return Column(
                  children: proposals.map((p) {
                    final status = p['status']?.toString() ?? 'pending_approval';
                    final pending = status == 'pending_approval';
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    p['file_path']?.toString() ?? '',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'monospace'),
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: _statusColor(status).withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    status,
                                    style: TextStyle(
                                        fontSize: 11, color: _statusColor(status)),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              p['reasoning']?.toString() ?? '',
                              style: const TextStyle(color: Colors.white70),
                            ),
                            if (p['error_log'] != null) ...[
                              const SizedBox(height: 8),
                              Text(
                                'Error: ${p['error_log']}',
                                style: const TextStyle(
                                    fontSize: 12, color: Colors.orangeAccent),
                              ),
                            ],
                            if (pending) ...[
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  OutlinedButton(
                                    onPressed:
                                        _busyId(p['id'] as int) ? null : () => _reject(p),
                                    child: const Text('Reject'),
                                  ),
                                  const SizedBox(width: 8),
                                  FilledButton(
                                    onPressed:
                                        _busyId(p['id'] as int) ? null : () => _approve(p),
                                    child: const Text('Approve & apply'),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
