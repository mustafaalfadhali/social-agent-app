import 'package:flutter/material.dart';

import '../models/social_account.dart';
import '../models/post.dart';
import '../services/api_service.dart';
import '../services/push_notifications.dart';
import '../theme/dataviz_colors.dart';
import '../widgets/radial_gauge.dart';
import '../widgets/voice_command_sheet.dart';
import 'dashboard_screen.dart';
import 'agent_screen.dart';
import 'login_screen.dart';

/// The "Jarvis" home screen - a HUD-style command center that's what you
/// see right after login, instead of landing straight on a plain list.
/// Everything on it is real, computed data (post outcomes, connected
/// accounts, agent run history) - no invented percentages standing in for
/// numbers we don't actually have.
class CommandCenterScreen extends StatefulWidget {
  const CommandCenterScreen({super.key});

  @override
  State<CommandCenterScreen> createState() => _CommandCenterScreenState();
}

class _CommandCenterScreenState extends State<CommandCenterScreen> {
  final _api = ApiService();
  late Future<_CommandCenterData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
    // Fire-and-forget: registers this device for push notifications if
    // Firebase is configured, silently does nothing if it isn't.
    PushNotifications.initAndRegister(_api);
  }

  Future<_CommandCenterData> _load() async {
    final results = await Future.wait([
      _api.getConnectedAccounts(),
      _api.getPosts(),
      _api.getAgentRuns(),
    ]);
    return _CommandCenterData(
      accounts: results[0] as List<SocialAccount>,
      posts: results[1] as List<SocialPost>,
      runs: results[2] as List<Map<String, dynamic>>,
    );
  }

  void _refresh() => setState(() => _future = _load());

  Future<void> _openVoiceCommand() async {
    final transcript = await VoiceCommandSheet.show(context);
    if (!mounted) return;
    _refresh();
    if (transcript != null && transcript.trim().isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Noted. Open a page in "Your Pages" → New post → the mic next '
            'to "Write with AI" to use a spoken topic as a caption.',
          ),
        ),
      );
    }
  }

  Future<void> _logout() async {
    await _api.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DataVizColors.chartSurface,
      appBar: AppBar(
        backgroundColor: DataVizColors.chartSurface,
        title: const Text('Command Center'),
        actions: [
          IconButton(
            onPressed: _logout,
            icon: const Icon(Icons.logout),
            tooltip: 'Log out',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => _refresh(),
        child: FutureBuilder<_CommandCenterData>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return ListView(
                padding: const EdgeInsets.all(20),
                children: [Text('Could not load: ${snapshot.error}')],
              );
            }
            final data = snapshot.data!;
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Center(
                  child: RadialGauge(
                    value: data.publishRate,
                    centerText: '${(data.publishRate * 100).round()}%',
                    centerSubtext: '${data.publishedCount}/${data.totalPosts} posts',
                    label: 'Published rate (all-time)',
                  ),
                ),
                const SizedBox(height: 28),
                Row(
                  children: [
                    Expanded(
                      child: _StatTile(
                        icon: Icons.link,
                        label: 'Connected pages',
                        value: '${data.accounts.length}',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _StatTile(
                        icon: Icons.pending_actions,
                        label: 'Awaiting approval',
                        value: '${data.pendingCount}',
                        highlight: data.pendingCount > 0,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _StatTile(
                        icon: Icons.schedule,
                        label: 'Last agent run',
                        value: data.lastRunLabel,
                        small: true,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    _StatusChip(
                      icon: Icons.check_circle,
                      label: 'Published',
                      count: data.publishedCount,
                      color: DataVizColors.statusGood,
                    ),
                    _StatusChip(
                      icon: Icons.hourglass_top,
                      label: 'Pending',
                      count: data.pendingCount,
                      color: DataVizColors.statusWarning,
                    ),
                    _StatusChip(
                      icon: Icons.cancel,
                      label: 'Rejected',
                      count: data.rejectedCount,
                      color: DataVizColors.statusSerious,
                    ),
                    _StatusChip(
                      icon: Icons.error,
                      label: 'Failed',
                      count: data.failedCount,
                      color: DataVizColors.statusCritical,
                    ),
                  ],
                ),
                const SizedBox(height: 28),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const DashboardScreen()),
                        ),
                        icon: const Icon(Icons.dashboard_outlined, size: 18),
                        label: const Text('Your Pages'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () async {
                          await Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => const AgentScreen()),
                          );
                          _refresh();
                        },
                        icon: const Icon(Icons.smart_toy_outlined, size: 18),
                        label: const Text('AI Agent'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 28),
                Text('Agent activity', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 10),
                if (data.runs.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Text(
                      'No agent runs yet - tap "AI Agent" to run the first review.',
                      style: TextStyle(color: DataVizColors.mutedInk),
                    ),
                  )
                else
                  ...data.runs.map((run) => _ActivityRow(run: run)),
              ],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openVoiceCommand,
        icon: const Icon(Icons.mic),
        label: const Text('Voice'),
      ),
    );
  }
}

class _CommandCenterData {
  _CommandCenterData({
    required this.accounts,
    required this.posts,
    required this.runs,
  });

  final List<SocialAccount> accounts;
  final List<SocialPost> posts;
  final List<Map<String, dynamic>> runs;

  int get totalPosts => posts.length;
  int get publishedCount => posts.where((p) => p.status == 'published').length;
  int get pendingCount => posts.where((p) => p.status == 'pending_approval').length;
  int get rejectedCount => posts.where((p) => p.status == 'rejected').length;
  int get failedCount => posts.where((p) => p.status == 'failed').length;

  double get publishRate => totalPosts == 0 ? 0 : publishedCount / totalPosts;

  String get lastRunLabel {
    if (runs.isEmpty) return 'Never';
    final raw = runs.first['created_at']?.toString();
    if (raw == null) return 'Never';
    final dt = DateTime.tryParse(raw);
    if (dt == null) return 'Never';
    return _timeAgo(dt);
  }
}

String _timeAgo(DateTime dt) {
  final diff = DateTime.now().toUtc().difference(dt.toUtc());
  if (diff.inMinutes < 1) return 'Just now';
  if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
  if (diff.inHours < 24) return '${diff.inHours}h ago';
  return '${diff.inDays}d ago';
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.icon,
    required this.label,
    required this.value,
    this.highlight = false,
    this.small = false,
  });

  final IconData icon;
  final String label;
  final String value;
  final bool highlight;
  final bool small;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF20221F),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: highlight ? DataVizColors.statusWarning.withOpacity(0.5) : DataVizColors.gridline,
        ),
      ),
      child: Column(
        children: [
          Icon(icon, size: 18, color: DataVizColors.secondaryInk),
          const SizedBox(height: 8),
          Text(
            value,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: small ? 14 : 20,
              fontWeight: FontWeight.w700,
              color: DataVizColors.primaryInk,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 11, color: DataVizColors.mutedInk),
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({
    required this.icon,
    required this.label,
    required this.count,
    required this.color,
  });

  final IconData icon;
  final String label;
  final int count;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 6),
          Text(
            '$label · $count',
            style: const TextStyle(fontSize: 12, color: DataVizColors.primaryInk),
          ),
        ],
      ),
    );
  }
}

class _ActivityRow extends StatelessWidget {
  const _ActivityRow({required this.run});

  final Map<String, dynamic> run;

  @override
  Widget build(BuildContext context) {
    final triggeredBy = run['triggered_by']?.toString() ?? 'manual';
    final summary = run['summary']?.toString() ?? '';
    final draftIds = (run['created_draft_ids'] as List?) ?? const [];
    final raw = run['created_at']?.toString();
    final dt = raw != null ? DateTime.tryParse(raw) : null;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF20221F),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            triggeredBy == 'scheduled' ? Icons.schedule : Icons.touch_app_outlined,
            size: 18,
            color: DataVizColors.secondaryInk,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(summary, style: const TextStyle(color: DataVizColors.primaryInk, fontSize: 13)),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      triggeredBy == 'scheduled' ? 'Scheduled run' : 'Manual run',
                      style: const TextStyle(fontSize: 11, color: DataVizColors.mutedInk),
                    ),
                    if (dt != null) ...[
                      const Text(' · ', style: TextStyle(fontSize: 11, color: DataVizColors.mutedInk)),
                      Text(_timeAgo(dt), style: const TextStyle(fontSize: 11, color: DataVizColors.mutedInk)),
                    ],
                    if (draftIds.isNotEmpty) ...[
                      const SizedBox(width: 8),
                      Icon(Icons.edit_note, size: 12, color: DataVizColors.statusWarning),
                      Text(
                        ' ${draftIds.length} draft(s)',
                        style: const TextStyle(fontSize: 11, color: DataVizColors.statusWarning),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
