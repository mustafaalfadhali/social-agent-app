import 'package:flutter/material.dart';

import '../models/social_account.dart';
import '../services/api_service.dart';
import '../widgets/voice_command_sheet.dart';
import 'design_editor_screen.dart';

class ComposerScreen extends StatefulWidget {
  const ComposerScreen({super.key, required this.accounts});

  final List<SocialAccount> accounts;

  @override
  State<ComposerScreen> createState() => _ComposerScreenState();
}

class _ComposerScreenState extends State<ComposerScreen> {
  final _api = ApiService();
  final _captionCtrl = TextEditingController();
  final _mediaUrlCtrl = TextEditingController();
  final Set<String> _selectedPlatforms = {};

  bool _publishing = false;
  bool _generatingText = false;
  bool _uploadingDesign = false;
  String? _resultMessage;

  Future<void> _publish() async {
    if (_captionCtrl.text.trim().isEmpty || _selectedPlatforms.isEmpty) {
      setState(() => _resultMessage =
          'Add a caption and select at least one platform.');
      return;
    }
    setState(() {
      _publishing = true;
      _resultMessage = null;
    });
    try {
      final post = await _api.createAndPublishPost(
        caption: _captionCtrl.text.trim(),
        mediaUrl: _mediaUrlCtrl.text.trim().isEmpty
            ? null
            : _mediaUrlCtrl.text.trim(),
        targetPlatforms: _selectedPlatforms.toList(),
      );
      setState(() => _resultMessage =
          'Status: ${post.status}\n${post.resultLog ?? ''}');
    } on ApiException catch (e) {
      setState(() => _resultMessage = 'Failed: ${e.message}');
    } finally {
      if (mounted) setState(() => _publishing = false);
    }
  }

  /// Opens a small dialog asking what the post should be about (unless
  /// [presetTopic] is already given, e.g. from the voice command sheet),
  /// calls the Claude-powered /content/generate-post endpoint, then lets
  /// the user pick one of the 3 returned variations to drop into the
  /// caption field.
  Future<void> _openAiWriter({String? presetTopic}) async {
    String topic;
    if (presetTopic != null && presetTopic.trim().isNotEmpty) {
      topic = presetTopic.trim();
    } else {
      final topicCtrl = TextEditingController();
      final entered = await showDialog<String>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Write with AI'),
          content: TextField(
            controller: topicCtrl,
            autofocus: true,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'What is this post about?',
              hintText: 'e.g. Weekend discount on our new espresso blend',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, topicCtrl.text.trim()),
              child: const Text('Generate'),
            ),
          ],
        ),
      );
      if (entered == null || entered.isEmpty) return;
      topic = entered;
    }

    setState(() => _generatingText = true);
    try {
      final platform = _selectedPlatforms.isNotEmpty
          ? _selectedPlatforms.first
          : 'instagram_business';
      final variations = await _api.generatePostContent(
        topic: topic,
        platform: platform,
      );
      if (!mounted) return;

      final chosen = await showDialog<Map<String, dynamic>>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Pick a version'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: variations.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, i) {
                final v = variations[i];
                return ListTile(
                  title: Text(v['caption'] as String, maxLines: 4, overflow: TextOverflow.ellipsis),
                  subtitle: Text((v['hashtags'] as List?)?.join(' ') ?? ''),
                  onTap: () => Navigator.pop(context, v),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
          ],
        ),
      );

      if (chosen != null) {
        final hashtags = (chosen['hashtags'] as List?)?.join(' ') ?? '';
        setState(() {
          _captionCtrl.text =
              hashtags.isEmpty ? chosen['caption'] : '${chosen['caption']}\n\n$hashtags';
        });
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Could not generate text: ${e.message}')));
    } finally {
      if (mounted) setState(() => _generatingText = false);
    }
  }

  /// Opens the in-app poster editor, then uploads the exported PNG so it
  /// has a public URL Meta's Graph API can fetch when publishing.
  Future<void> _openDesignEditor() async {
    final exportedPath = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => const DesignEditorScreen()),
    );
    if (exportedPath == null) return;

    setState(() => _uploadingDesign = true);
    try {
      final url = await _api.uploadMedia(exportedPath);
      setState(() => _mediaUrlCtrl.text = url);
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Upload failed: ${e.message}')));
    } finally {
      if (mounted) setState(() => _uploadingDesign = false);
    }
  }

  /// Push-to-talk topic capture - opens the same voice sheet used on the
  /// Command Center, but in topic-only mode, and feeds the transcript
  /// straight into the AI writer instead of the manual dialog.
  Future<void> _openVoiceTopic() async {
    final transcript = await VoiceCommandSheet.show(
      context,
      mode: VoiceSheetMode.topicOnly,
    );
    if (transcript != null && transcript.trim().isNotEmpty) {
      await _openAiWriter(presetTopic: transcript);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Unique platforms available among connected accounts (a business may
    // have both a Facebook Page and a linked Instagram Business account).
    final platforms = widget.accounts.map((a) => a.platform).toSet().toList();

    return Scaffold(
      appBar: AppBar(title: const Text('New post')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Publish to', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: platforms.map((p) {
                final selected = _selectedPlatforms.contains(p);
                return FilterChip(
                  label: Text(p == 'instagram_business' ? 'Instagram' : 'Facebook'),
                  selected: selected,
                  onSelected: (v) => setState(() {
                    if (v) {
                      _selectedPlatforms.add(p);
                    } else {
                      _selectedPlatforms.remove(p);
                    }
                  }),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _captionCtrl,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Caption / ad copy',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _generatingText ? null : () => _openAiWriter(),
                    icon: _generatingText
                        ? const SizedBox(
                            height: 16,
                            width: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.auto_awesome, size: 18),
                    label: const Text('Write with AI'),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton(
                  onPressed: _generatingText ? null : _openVoiceTopic,
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                  ),
                  child: const Icon(Icons.mic_none, size: 18),
                ),
              ],
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _mediaUrlCtrl,
              decoration: const InputDecoration(
                labelText: 'Image/poster URL',
                hintText: 'https://… (or design one below)',
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _uploadingDesign ? null : _openDesignEditor,
              icon: _uploadingDesign
                  ? const SizedBox(
                      height: 16,
                      width: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.brush_outlined, size: 18),
              label: Text(_uploadingDesign ? 'Uploading…' : 'Design a poster'),
            ),
            if (_mediaUrlCtrl.text.isNotEmpty) ...[
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  _mediaUrlCtrl.text,
                  height: 160,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    height: 80,
                    alignment: Alignment.center,
                    color: Colors.white10,
                    child: const Text('Preview unavailable',
                        style: TextStyle(color: Colors.white38)),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _publishing ? null : _publish,
              icon: _publishing
                  ? const SizedBox(
                      height: 16,
                      width: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.send_outlined),
              label: const Text('Publish now'),
            ),
            if (_resultMessage != null) ...[
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text(_resultMessage!),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
