import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../theme/dataviz_colors.dart';

class _ChatMessage {
  _ChatMessage({required this.role, required this.content});
  final String role; // 'user' | 'assistant'
  final String content;
}

/// A direct, open-ended chat with Claude - separate from "Write with AI"
/// (which only produces post captions) and the autonomous Agent screen
/// (which reviews accounts and drafts posts on its own). This is just a
/// conversation: ask questions, brainstorm, get marketing advice.
///
/// Stateless on the backend (see routers/chat.py) - the whole transcript
/// lives only in this screen's State and is resent with every message, so
/// closing the screen clears the conversation. Fine for a lightweight
/// assistant chat; add persistence later if that turns out to matter.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _api = ApiService();
  final _inputCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<_ChatMessage> _messages = [];
  bool _sending = false;

  Future<void> _send() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty || _sending) return;

    setState(() {
      _messages.add(_ChatMessage(role: 'user', content: text));
      _sending = true;
    });
    _inputCtrl.clear();
    _scrollToEnd();

    try {
      final reply = await _api.sendChatMessage(
        _messages
            .map((m) => {'role': m.role, 'content': m.content})
            .toList(),
      );
      if (!mounted) return;
      setState(() => _messages.add(_ChatMessage(role: 'assistant', content: reply)));
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _messages.add(
          _ChatMessage(role: 'assistant', content: 'Error: ${e.message}')));
    } finally {
      if (mounted) setState(() => _sending = false);
      _scrollToEnd();
    }
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollCtrl.hasClients) return;
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chat')),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Text(
                        'Ask anything - content ideas, marketing advice, '
                        'questions about your page.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: DataVizColors.mutedInk),
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.all(16),
                    itemCount: _messages.length,
                    itemBuilder: (context, i) => _bubble(_messages[i]),
                  ),
          ),
          if (_sending)
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: SizedBox(
                height: 16,
                width: 16,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _inputCtrl,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: const InputDecoration(
                        hintText: 'Message…',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _sending ? null : _send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bubble(_ChatMessage message) {
    final isUser = message.role == 'user';
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.78,
        ),
        decoration: BoxDecoration(
          color: isUser
              ? Theme.of(context).colorScheme.primary.withOpacity(0.85)
              : DataVizColors.chartSurface,
          borderRadius: BorderRadius.circular(16),
          border: isUser ? null : Border.all(color: DataVizColors.gridline),
        ),
        child: Text(
          message.content,
          style: TextStyle(
            color: isUser ? Colors.white : DataVizColors.primaryInk,
          ),
        ),
      ),
    );
  }
}
