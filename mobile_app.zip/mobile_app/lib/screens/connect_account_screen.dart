import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../services/api_service.dart';

/// Opens the Meta OAuth consent dialog in a webview. When Meta redirects
/// back to our META_REDIRECT_URI (see backend/.env), we intercept the
/// navigation *before* the webview tries to load it, pull out `code` and
/// `state`, and exchange them for connected accounts via the backend.
class ConnectAccountScreen extends StatefulWidget {
  const ConnectAccountScreen({super.key, required this.redirectUriPrefix});

  /// Must match META_REDIRECT_URI in the backend .env, e.g.
  /// "http://localhost:8000/meta/callback"
  final String redirectUriPrefix;

  @override
  State<ConnectAccountScreen> createState() => _ConnectAccountScreenState();
}

class _ConnectAccountScreenState extends State<ConnectAccountScreen> {
  final _api = ApiService();
  late final WebViewController _controller;
  bool _loading = true;
  bool _exchanging = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() => _loading = true),
          onPageFinished: (_) => setState(() => _loading = false),
          onNavigationRequest: (request) {
            if (request.url.startsWith(widget.redirectUriPrefix)) {
              _handleRedirect(request.url);
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      );
    _load();
  }

  Future<void> _load() async {
    try {
      final url = await _api.getMetaConnectUrl();
      await _controller.loadRequest(Uri.parse(url));
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    }
  }

  Future<void> _handleRedirect(String url) async {
    final uri = Uri.parse(url);
    final code = uri.queryParameters['code'];
    final state = uri.queryParameters['state'];
    final metaError = uri.queryParameters['error_description'];

    if (metaError != null) {
      setState(() => _error = metaError);
      return;
    }
    if (code == null || state == null) {
      setState(() => _error = 'Missing code/state in redirect.');
      return;
    }

    setState(() => _exchanging = true);
    try {
      final accounts =
          await _api.completeMetaCallback(code: code, state: state);
      if (!mounted) return;
      Navigator.of(context).pop(accounts);
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _exchanging = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Connect Meta account')),
      body: Stack(
        children: [
          if (_error == null) WebViewWidget(controller: _controller),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, color: Colors.redAccent, size: 40),
                    const SizedBox(height: 12),
                    Text(_error!, textAlign: TextAlign.center),
                  ],
                ),
              ),
            ),
          if (_loading || _exchanging)
            const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}
