import json

from anthropic import Anthropic

from ..config import settings

_client: Anthropic | None = None


def get_client() -> Anthropic:
    global _client
    if _client is None:
        _client = Anthropic(api_key=settings.anthropic_api_key)
    return _client


ANALYSIS_SYSTEM_PROMPT = """You are a senior social media strategist embedded in a \
business analytics app. You are given raw engagement metrics for one social \
media page/account. Analyze the numbers and return ONLY a JSON object (no \
markdown, no prose outside the JSON) with this exact shape:

{
  "summary": "2-3 sentence plain-language summary of how this page is performing",
  "strengths": ["short bullet", "short bullet", "short bullet"],
  "recommendations": ["short actionable bullet", "short actionable bullet"],
  "best_posting_times": ["e.g. Weekdays 7-9 PM", "e.g. Fri-Sat 12-2 PM"]
}

Be specific and reference the actual numbers given. Do not invent data you \
were not given."""


def analyze_page_metrics(platform: str, metrics: dict) -> dict:
    """
    Sends page/post engagement metrics to Claude and asks it to return a
    structured strengths/recommendations analysis as JSON.
    """
    client = get_client()
    message = client.messages.create(
        model=settings.claude_model,
        max_tokens=1536,  # same truncation risk as generate_post_variations below
        system=ANALYSIS_SYSTEM_PROMPT,
        messages=[
            {
                "role": "user",
                "content": (
                    f"Platform: {platform}\n"
                    f"Metrics (JSON):\n{json.dumps(metrics, ensure_ascii=False)}"
                ),
            }
        ],
    )
    return _parse_json_response(message)


GENERATION_SYSTEM_PROMPT = """You are a social media copywriter for a \
business. Given a topic/brief, write ready-to-publish post content. Return \
ONLY a JSON object (no markdown, no prose outside the JSON) with this exact \
shape:

{
  "variations": [
    {"caption": "full post text, including relevant emoji if appropriate", "hashtags": ["#tag1", "#tag2"]},
    {"caption": "a second, differently-angled version", "hashtags": ["#tag1", "#tag2"]},
    {"caption": "a third version", "hashtags": ["#tag1", "#tag2"]}
  ]
}

Match the requested platform's conventions (Instagram: punchy + emoji + \
hashtags at the end; Facebook: slightly longer, conversational; article: \
longer-form with a clear structure, minimal hashtags). Match the requested \
tone and language. Do not use placeholder brackets like [Your Business] -\
write natural, ready-to-post copy."""


def generate_post_variations(
    topic: str,
    platform: str = "instagram_business",
    tone: str = "friendly and professional",
    language: str = "Arabic",
) -> dict:
    """Shared by POST /content/generate-post and the agent's
    generate_post_content tool, so both produce content the same way."""
    client = get_client()
    message = client.messages.create(
        model=settings.claude_model,
        # 1200 was too tight for Arabic (non-Latin scripts cost more tokens
        # per character than English), which was silently truncating the
        # JSON response mid-string and crashing _parse_json_response with
        # JSONDecodeError - hit in production via the agent's
        # generate_post_content tool. 2048 gives 3 caption variations +
        # hashtags in Arabic real headroom.
        max_tokens=2048,
        system=GENERATION_SYSTEM_PROMPT,
        messages=[
            {
                "role": "user",
                "content": (
                    f"Topic/brief: {topic}\n"
                    f"Platform: {platform}\n"
                    f"Tone: {tone}\n"
                    f"Language: {language}\n"
                    "Write 3 variations."
                ),
            }
        ],
    )
    return _parse_json_response(message)


CHAT_SYSTEM_PROMPT = """You are the in-app AI assistant for a small \
business's social media management app. The business owner can talk to you \
directly here about anything related to running their social media presence: \
brainstorming content ideas, planning campaigns, questions about their \
connected Facebook Page/Instagram account, or general marketing advice. Keep \
replies conversational, concise, and practical - this is a chat, not a \
report. Reply in the same language the user writes in (default to Arabic if \
unclear). You cannot directly publish posts or take actions yourself from \
this chat (that happens through the app's other screens) - if the user asks \
you to actually do something like publish a post, tell them which screen/\
button in the app does that instead of pretending you did it."""


def chat_reply(messages: list[dict]) -> str:
    """
    Free-form conversational chat, powering the in-app 'Chat' screen -
    unlike analyze_page_metrics/generate_post_variations above, this
    returns plain text, not structured JSON. `messages` is the full
    transcript so far as a list of {"role": "user"|"assistant", "content": str}
    dicts, sent stateless by the client each turn (see ChatScreen /
    ApiService.sendChatMessage on the mobile side) - the backend does not
    persist chat history.
    """
    client = get_client()
    message = client.messages.create(
        model=settings.claude_model,
        max_tokens=1536,
        system=CHAT_SYSTEM_PROMPT,
        messages=messages,
    )
    return "".join(block.text for block in message.content if block.type == "text")


def _parse_json_response(message) -> dict:
    text = "".join(block.text for block in message.content if block.type == "text")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Model occasionally wraps JSON in a code fence - strip it and retry once.
        cleaned = text.strip().strip("`").removeprefix("json").strip()
        return json.loads(cleaned)
