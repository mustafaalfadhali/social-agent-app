"""
Tools for the self-development agent (services/self_dev_runner.py): reading
its own backend source code, and PROPOSING (never applying) a change to it.

Safety design, all enforced here so it can't be bypassed by anything the
model says in a prompt:
  - Only .py files under app/services/ or app/routers/ can ever be touched -
    never config.py, security.py, database.py, main.py, the Dockerfile, or
    .env (those live directly under app/ or backend/, outside both allowed
    roots, so they're excluded by construction).
  - The self-dev machinery's own files (this file, self_dev_runner.py,
    routers/self_dev.py) are explicitly blocked, so the agent can never
    edit the mechanism that constrains it.
  - propose_code_change only ever creates a CodeProposal row
    (status="pending_approval") - it NEVER writes to disk. The only code
    path that writes a real file is approve_code_proposal in
    routers/self_dev.py, triggered exclusively by an explicit human tap.
"""
from pathlib import Path

from sqlalchemy.orm import Session

from ..models import CodeProposal

BACKEND_ROOT = Path(__file__).resolve().parent.parent.parent  # .../backend
APP_ROOT = BACKEND_ROOT / "app"

ALLOWED_ROOTS = [APP_ROOT / "services", APP_ROOT / "routers"]

# The self-dev system's own files - never editable by the agent itself.
BLOCKED_RELATIVE_PATHS = {
    "app/services/self_dev_tools.py",
    "app/services/self_dev_runner.py",
    "app/routers/self_dev.py",
}


def validate_own_source_path(relative_path: str) -> Path:
    """Resolves relative_path (as given by the model, relative to backend/)
    and raises ValueError unless it's a real .py file safely inside one of
    ALLOWED_ROOTS. Raising (not silently correcting) is deliberate - a path
    the model got wrong should surface as a clear tool error, not get
    quietly redirected somewhere it didn't ask for."""
    if not relative_path.endswith(".py"):
        raise ValueError("only .py files can be read or proposed")

    if relative_path in BLOCKED_RELATIVE_PATHS:
        raise ValueError(
            "this file is part of the self-development system itself and "
            "can never be modified by the agent"
        )

    candidate = (BACKEND_ROOT / relative_path).resolve()

    if not any(
        candidate == root or root in candidate.parents for root in ALLOWED_ROOTS
    ):
        raise ValueError(
            "path is outside the allowed directories (app/services/, "
            "app/routers/) - refusing"
        )

    return candidate


def list_own_source_files() -> dict:
    """Lists every file the agent is allowed to read/propose changes to."""
    files = []
    for root in ALLOWED_ROOTS:
        if not root.exists():
            continue
        for path in sorted(root.rglob("*.py")):
            rel = path.relative_to(BACKEND_ROOT).as_posix()
            if rel in BLOCKED_RELATIVE_PATHS:
                continue
            files.append(rel)
    return {"files": files}


def read_own_source_file(relative_path: str) -> dict:
    try:
        path = validate_own_source_path(relative_path)
    except ValueError as exc:
        return {"error": str(exc)}

    if not path.exists():
        return {"error": f"{relative_path} does not exist"}

    return {"file_path": relative_path, "content": path.read_text(encoding="utf-8")}


def propose_code_change(
    db: Session,
    owner_id: int,
    relative_path: str,
    new_content: str,
    reasoning: str,
) -> dict:
    """Creates a pending CodeProposal row. Never touches disk - see module
    docstring. Snapshots the file's CURRENT content as old_content so the
    human reviewer (and the app's diff view) can see exactly what's
    changing, even if the file changes again before they get to review it."""
    try:
        path = validate_own_source_path(relative_path)
    except ValueError as exc:
        return {"error": str(exc)}

    old_content = path.read_text(encoding="utf-8") if path.exists() else None

    proposal = CodeProposal(
        owner_id=owner_id,
        file_path=relative_path,
        reasoning=reasoning,
        old_content=old_content,
        new_content=new_content,
        status="pending_approval",
    )
    db.add(proposal)
    db.commit()
    db.refresh(proposal)
    return {"proposal_id": proposal.id, "status": proposal.status}
