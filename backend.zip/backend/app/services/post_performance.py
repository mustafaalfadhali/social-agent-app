"""
Looks up how one *specific* published post performed - not just the page's
aggregate weekly metrics (that's meta_insights.py). This is what closes the
feedback loop: the agent drafted this, a human approved it, did it actually
work? See get_recent_performance in agent_tools.py for how the agent reads
this back.
"""
import httpx

from ..config import settings
from ..models import SocialAccount

GRAPH_BASE = f"https://graph.facebook.com/{settings.meta_graph_api_version}"


async def get_real_post_performance(account: SocialAccount, platform_post_id: str) -> dict:
    async with httpx.AsyncClient() as client:
        if account.platform == "instagram_business":
            resp = await client.get(
                f"{GRAPH_BASE}/{platform_post_id}",
                params={
                    "fields": "like_count,comments_count",
                    "access_token": account.access_token,
                },
            )
        else:
            resp = await client.get(
                f"{GRAPH_BASE}/{platform_post_id}/insights",
                params={
                    "metric": "post_impressions,post_engaged_users",
                    "access_token": account.access_token,
                },
            )
        resp.raise_for_status()
        return resp.json()


def get_mock_post_performance(platform: str) -> dict:
    """Realistic placeholder so the feedback loop is demoable before Meta
    App Review is approved and real per-post insights are reachable."""
    if platform == "instagram_business":
        return {"like_count": 214, "comments_count": 12}
    return {"reactions": 58, "comments": 6, "shares": 3, "impressions": 3100}
