"""
Read-only web browsing tool for the agent - lets it open a real webpage and
read its visible content, for information that has no dedicated API/tool
(e.g. checking a Google Business review page, a competitor's site, or any
public page). Uses Playwright's headless Chromium - the same underlying
technology behind "browser automation" agents like Manus.

Deliberately READ-ONLY for this first version (no clicking/typing/submitting
forms yet) - a safe first step. Giving the agent the ability to take actions
on external sites (click "reply", submit a form) is a real capability
increase that deserves its own deliberate follow-up, same way create_draft_post
never publishes directly without human approval.
"""
from playwright.async_api import async_playwright

MAX_TEXT_CHARS = 6000  # keep the agent's context/token usage bounded
PAGE_LOAD_TIMEOUT_MS = 20000


async def browse_webpage(url: str) -> dict:
    if not url or not url.startswith(("http://", "https://")):
        return {"error": "invalid or missing url - must start with http:// or https://"}

    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            try:
                await page.goto(url, timeout=PAGE_LOAD_TIMEOUT_MS, wait_until="domcontentloaded")
                # Give lightweight JS-rendered pages a moment to settle
                # before reading the DOM.
                await page.wait_for_timeout(1500)
                text = await page.inner_text("body")
                title = await page.title()
            finally:
                await browser.close()
    except Exception as exc:  # noqa: BLE001
        return {"error": f"failed to load page: {exc}"}

    text = " ".join(text.split())  # collapse whitespace/newlines
    truncated = len(text) > MAX_TEXT_CHARS
    return {
        "url": url,
        "title": title,
        "text": text[:MAX_TEXT_CHARS],
        "truncated": truncated,
    }
