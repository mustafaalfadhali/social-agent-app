"""
What actually makes the agent "run in the background" rather than only when
someone taps a button. An APScheduler cron job fires on `AGENT_SCHEDULE_CRON`
(default daily, 09:00 UTC) and runs one agent cycle for every user who has at
least one connected social account - each in its own DB session, with
per-user error isolation so one account's failure doesn't skip everyone
else's run.

This is intentionally simple (in-process APScheduler, not a separate worker
+ queue) because it matches the rest of this scaffold: correct and good
enough to build on for a single backend instance. If you deploy multiple
backend replicas, an in-process scheduler will fire once *per replica* -
switch to a proper job queue (Celery beat, an external cron hitting an
internal endpoint, etc.) before scaling out.
"""
import json
import logging
from datetime import datetime, timedelta, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from ..config import settings
from ..database import SessionLocal
from ..models import User, SocialAccount, Post
from .agent_runner import execute_and_log_agent_run
from .post_performance import get_real_post_performance, get_mock_post_performance

logger = logging.getLogger("agent_scheduler")

scheduler = AsyncIOScheduler()


async def run_scheduled_agent_for_all_users() -> None:
    if not settings.anthropic_api_key:
        logger.info("Skipping scheduled agent run: ANTHROPIC_API_KEY is not set.")
        return

    db = SessionLocal()
    try:
        user_ids = [
            row[0] for row in db.query(SocialAccount.owner_id).distinct().all()
        ]
    finally:
        db.close()

    logger.info("Scheduled agent run starting for %d user(s).", len(user_ids))

    for user_id in user_ids:
        db = SessionLocal()
        try:
            user = db.query(User).filter(User.id == user_id).first()
            if not user:
                continue
            result = await execute_and_log_agent_run(user, db, triggered_by="scheduled")
            logger.info(
                "Scheduled agent run for user %s: %s draft(s) created.",
                user_id,
                len(result.get("created_draft_ids", [])),
            )
        except Exception:  # noqa: BLE001 - one user's failure must not stop the rest
            logger.exception("Scheduled agent run failed for user %s", user_id)
        finally:
            db.close()


async def refresh_post_performance_for_all_users() -> None:
    """Closes the feedback loop: for every published post old enough to have
    accumulated real engagement (PERFORMANCE_CHECK_MIN_AGE_HOURS) that
    hasn't been checked yet, look up its actual performance and store it.
    The agent reads this back via the get_recent_performance tool."""
    cutoff = datetime.now(timezone.utc) - timedelta(
        hours=settings.performance_check_min_age_hours
    )

    db = SessionLocal()
    try:
        candidates = (
            db.query(Post)
            .filter(
                Post.status == "published",
                Post.performance_checked_at.is_(None),
                Post.published_at.isnot(None),
                Post.published_at <= cutoff,
                Post.platform_post_ids.isnot(None),
            )
            .all()
        )
        candidate_ids = [p.id for p in candidates]
    finally:
        db.close()

    if not candidate_ids:
        return

    logger.info("Checking performance for %d published post(s).", len(candidate_ids))

    for post_id in candidate_ids:
        db = SessionLocal()
        try:
            post = db.query(Post).filter(Post.id == post_id).first()
            if not post or not post.platform_post_ids:
                continue

            platform_ids: dict = json.loads(post.platform_post_ids)
            performance: dict = {}
            for platform, platform_post_id in platform_ids.items():
                account = (
                    db.query(SocialAccount)
                    .filter(
                        SocialAccount.owner_id == post.owner_id,
                        SocialAccount.platform == platform,
                    )
                    .first()
                )
                if not account:
                    continue
                try:
                    performance[platform] = await get_real_post_performance(
                        account, platform_post_id
                    )
                except Exception:
                    performance[platform] = get_mock_post_performance(platform)

            post.performance_json = json.dumps(performance, default=str)
            post.performance_checked_at = datetime.now(timezone.utc)
            db.commit()
        except Exception:  # noqa: BLE001
            logger.exception("Performance check failed for post %s", post_id)
        finally:
            db.close()


def start_scheduler() -> None:
    if settings.agent_schedule_enabled:
        scheduler.add_job(
            run_scheduled_agent_for_all_users,
            CronTrigger.from_crontab(settings.agent_schedule_cron),
            id="agent_daily_run",
            replace_existing=True,
            misfire_grace_time=3600,
        )
        logger.info("Agent scheduler enabled (cron: %s).", settings.agent_schedule_cron)
    else:
        logger.info("Agent scheduler disabled (AGENT_SCHEDULE_ENABLED=false).")

    if settings.performance_check_enabled:
        scheduler.add_job(
            refresh_post_performance_for_all_users,
            CronTrigger.from_crontab(settings.performance_check_cron),
            id="performance_check_run",
            replace_existing=True,
            misfire_grace_time=3600,
        )
        logger.info(
            "Performance check scheduler enabled (cron: %s).",
            settings.performance_check_cron,
        )
    else:
        logger.info("Performance check scheduler disabled (PERFORMANCE_CHECK_ENABLED=false).")

    scheduler.start()


def stop_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
