"""
Pulls engagement metrics for a connected Page/Instagram account from the
Graph API. For local development without an approved Meta App, use
`get_mock_metrics` so the rest of the pipeline (Claude analysis, UI) can be
built and demoed before App Review is approved.
"""
import httpx

from ..config import settings
from ..models import SocialAccount

GRAPH_BASE = f"https://graph.facebook.com/{settings.meta_graph_api_version}"


async def get_real_metrics(account: SocialAccount) -> dict:
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{GRAPH_BASE}/{account.platform_account_id}/insights",
            params={
                "metric": "page_impressions,page_engaged_users,page_post_engagements",
                "period": "week",
                "access_token": account.access_token,
            },
        )
        resp.raise_for_status()
        return resp.json()


def get_mock_metrics(platform: str) -> dict:
    """Realistic placeholder data so you can demo the analysis flow before
    Meta App Review is approved."""
    if platform == "instagram_business":
        return {
            "followers": 8420,
            "avg_reach_per_post": 3100,
            "avg_engagement_rate_pct": 4.8,
            "top_content_type": "Reels (short video)",
            "engagement_by_content_type": {
                "reel": 6.9,
                "carousel": 4.1,
                "single_image": 2.3,
            },
            "posting_times_engagement": {
                "Mon 8-9am": 2.1,
                "Wed 1-2pm": 3.0,
                "Fri 8-9pm": 6.4,
                "Sat 12-2pm": 5.8,
            },
        }
    return {
        "followers": 12500,
        "avg_reach_per_post": 4200,
        "avg_engagement_rate_pct": 2.9,
        "top_content_type": "Image + link posts",
        "engagement_by_content_type": {
            "video": 4.5,
            "image": 2.6,
            "link": 1.4,
        },
        "posting_times_engagement": {
            "Mon 9-10am": 1.8,
            "Thu 6-7pm": 3.9,
            "Sun 11am-12pm": 3.2,
        },
    }
