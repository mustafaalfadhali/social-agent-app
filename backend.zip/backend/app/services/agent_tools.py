"""
Tool definitions the agent can call, and the code that actually executes
each one. This is the "hands" of the agent - Claude decides *which* of these
to call and with *what arguments*; this module is what actually touches the
database / Graph API / Claude again on its behalf.

Keep `create_draft_post` as the only tool capable of producing a post, and
keep it creating drafts (status="pending_approval") rather than publishing -
that's what keeps a human in the loop before anything goes live.
"""
import json

from sqlalchemy.orm import Session

from ..models import User, SocialAccount, Post
from .claude_client import analyze_page_metrics, generate_post_variations
from .meta_insights import get_real_metrics, get_mock_metrics
from .web_search import search_trends
from .browser_tool import browse_webpage

TOOLS = [
    {
        "name": "list_connected_accounts",
        "description": (
            "List the social media accounts (Facebook Pages / Instagram "
            "Business accounts) this user has connected. Always call this "
            "first."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_account_analysis",
        "description": (
            "Get an engagement analysis (summary, strengths, "
            "recommendations, best posting times) for one connected "
            "account, based on its recent metrics."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "social_account_id": {
                    "type": "integer",
                    "description": "id from list_connected_accounts",
                }
            },
            "required": ["social_account_id"],
        },
    },
    {
        "name": "generate_post_content",
        "description": "Generate 3 ready-to-publish caption variations for a given topic and platform.",
        "input_schema": {
            "type": "object",
            "properties": {
                "topic": {"type": "string"},
                "platform": {
                    "type": "string",
                    "description": "facebook_page or instagram_business",
                },
                "tone": {"type": "string"},
            },
            "required": ["topic", "platform"],
        },
    },
    {
        "name": "get_recent_feedback",
        "description": (
            "See how your last several drafts were received - which were "
            "approved & published vs rejected, and any reason the human "
            "gave when rejecting. Call this BEFORE drafting new content so "
            "you don't repeat something that recently missed, and so you "
            "can lean into what's been working. Always call this at least "
            "once per run."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_recent_performance",
        "description": (
            "See how your past drafts actually performed after publishing "
            "(likes/comments/engagement on the specific posts you wrote) - "
            "not just page-level trends. Posts published too recently to "
            "have real numbers yet are marked as such. Use this alongside "
            "get_recent_feedback to judge whether what got approved also "
            "actually worked, not just whether it got approved."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "search_trends",
        "description": (
            "Search the live web for current news/trends related to a "
            "query - use this if a timely or current-events angle could "
            "make a post noticeably more relevant (e.g. a seasonal moment, "
            "a local event, something happening in the account's "
            "industry right now). May report itself as unavailable if the "
            "server isn't configured for it - in that case just proceed "
            "without a trend angle, don't treat it as an error."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query, e.g. 'ريادة الأعمال في السعودية اتجاهات 2026'",
                }
            },
            "required": ["query"],
        },
    },
    {
        "name": "browse_webpage",
        "description": (
            "Open a real webpage and read its visible text content - works "
            "like a person opening the page in a browser. Use this for "
            "information that has no dedicated tool, e.g. checking a "
            "Google Business reviews page, a competitor's site, or any "
            "other public page relevant to deciding what to post. This is "
            "READ-ONLY for now - it cannot click buttons, log in, or "
            "submit forms."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "Full URL to open, including https://",
                }
            },
            "required": ["url"],
        },
    },
    {
        "name": "create_draft_post",
        "description": (
            "Create a draft post that will be shown to the human owner for "
            "approval. This is the ONLY way to produce content - you can "
            "NEVER publish directly, no matter how confident you are. "
            "Always include your reasoning."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "social_account_id": {
                    "type": "integer",
                    "description": "Which connected account this draft is for",
                },
                "caption": {"type": "string"},
                "target_platforms": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": 'e.g. ["facebook_page"] or ["instagram_business"]',
                },
                "reasoning": {
                    "type": "string",
                    "description": "Why this post and why now - shown to the human reviewer",
                },
            },
            "required": ["caption", "target_platforms", "reasoning"],
        },
    },
    {
        "name": "finish",
        "description": "Call this when you're done reviewing accounts for this run, whether or not you created a draft.",
        "input_schema": {
            "type": "object",
            "properties": {"summary": {"type": "string"}},
            "required": ["summary"],
        },
    },
]


async def execute_tool(
    name: str,
    tool_input: dict,
    user: User,
    db: Session,
    created_draft_ids: list[int],
) -> dict:
    if name == "list_connected_accounts":
        accounts = (
            db.query(SocialAccount).filter(SocialAccount.owner_id == user.id).all()
        )
        return {
            "accounts": [
                {"id": a.id, "platform": a.platform, "display_name": a.display_name}
                for a in accounts
            ]
        }

    if name == "get_account_analysis":
        account = (
            db.query(SocialAccount)
            .filter(
                SocialAccount.id == tool_input.get("social_account_id"),
                SocialAccount.owner_id == user.id,
            )
            .first()
        )
        if not account:
            return {"error": "account not found"}
        try:
            metrics = await get_real_metrics(account)
        except Exception:
            metrics = get_mock_metrics(account.platform)
        return analyze_page_metrics(account.platform, metrics)

    if name == "generate_post_content":
        return generate_post_variations(
            topic=tool_input.get("topic", ""),
            platform=tool_input.get("platform", "instagram_business"),
            tone=tool_input.get("tone", "friendly and professional"),
        )

    if name == "get_recent_feedback":
        recent = (
            db.query(Post)
            .filter(
                Post.owner_id == user.id,
                Post.status.in_(["published", "rejected"]),
            )
            .order_by(Post.created_at.desc())
            .limit(8)
            .all()
        )
        return {
            "recent_posts": [
                {
                    "caption_excerpt": p.caption[:140],
                    "status": p.status,
                    "human_feedback": p.feedback,
                }
                for p in recent
            ]
        }

    if name == "get_recent_performance":
        recent = (
            db.query(Post)
            .filter(Post.owner_id == user.id, Post.status == "published")
            .order_by(Post.created_at.desc())
            .limit(8)
            .all()
        )
        posts_out = []
        for p in recent:
            if p.performance_json:
                performance = json.loads(p.performance_json)
                measured = True
            else:
                performance = None
                measured = False
            posts_out.append(
                {
                    "caption_excerpt": p.caption[:140],
                    "performance_measured": measured,
                    "performance": performance,
                }
            )
        return {"recent_published_posts": posts_out}

    if name == "search_trends":
        return await search_trends(tool_input.get("query", ""))

    if name == "browse_webpage":
        return await browse_webpage(tool_input.get("url", ""))

    if name == "create_draft_post":
        # Hard safety net behind the prompt's "up to MAX_DRAFTS_PER_RUN"
        # instruction (agent_runner.AGENT_SYSTEM_PROMPT) - don't rely on the
        # model alone to respect the cap.
        from .agent_runner import MAX_DRAFTS_PER_RUN

        if len(created_draft_ids) >= MAX_DRAFTS_PER_RUN:
            return {
                "error": (
                    f"Draft limit reached ({MAX_DRAFTS_PER_RUN} per run) - "
                    "call finish now instead of creating more drafts."
                )
            }

        post = Post(
            owner_id=user.id,
            caption=tool_input.get("caption", ""),
            target_platforms=",".join(tool_input.get("target_platforms", [])),
            status="pending_approval",
            result_log=f"Agent reasoning: {tool_input.get('reasoning', '')}",
        )
        db.add(post)
        db.commit()
        db.refresh(post)
        created_draft_ids.append(post.id)
        return {"post_id": post.id, "status": post.status}

    return {"error": f"unknown tool '{name}'"}
