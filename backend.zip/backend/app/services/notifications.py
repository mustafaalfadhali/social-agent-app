"""
Push notifications for "a new draft is waiting for you" - what makes the
scheduler's unattended agent runs (services/scheduler.py) actually reach
you, instead of only being visible if you happen to open the app. Uses
Firebase Cloud Messaging via firebase-admin.

Setup (same spirit as the Meta credentials - your own free project, not
something bundled with this scaffold):
1. Create a project at https://console.firebase.google.com (free).
2. Project settings -> Service accounts -> Generate new private key. Save
   the downloaded JSON file into the backend/ folder (do NOT commit it -
   add it to .gitignore) and set FIREBASE_SERVICE_ACCOUNT_PATH in .env to
   its filename.
3. In the mobile app: `dart pub global activate flutterfire_cli`, then
   `flutterfire configure` from inside mobile_app/ (after `flutter create .`)
   - this registers the Android app with the same Firebase project and
   wires the native Gradle config automatically.

Until FIREBASE_SERVICE_ACCOUNT_PATH is set, this module no-ops quietly on
every call - everything else in the app works fine without it, you just
won't get a push when a draft is created.
"""
import logging

from ..config import settings
from ..models import User

logger = logging.getLogger("notifications")

_firebase_app = None
_init_attempted = False


def _get_firebase_app():
    global _firebase_app, _init_attempted
    if _init_attempted:
        return _firebase_app
    _init_attempted = True

    if not settings.firebase_service_account_path:
        logger.info(
            "Push notifications disabled (FIREBASE_SERVICE_ACCOUNT_PATH not set)."
        )
        return None

    try:
        import firebase_admin
        from firebase_admin import credentials

        cred = credentials.Certificate(settings.firebase_service_account_path)
        _firebase_app = firebase_admin.initialize_app(cred)
        logger.info("Firebase initialized for push notifications.")
    except Exception:  # noqa: BLE001
        logger.exception("Failed to initialize Firebase - push notifications disabled.")
        _firebase_app = None
    return _firebase_app


def notify_user(user: User, title: str, body: str) -> None:
    """Best-effort - never raises. A failed push should never break an
    agent run or an API request."""
    if not user.device_token:
        return

    app = _get_firebase_app()
    if app is None:
        return

    try:
        from firebase_admin import messaging

        message = messaging.Message(
            notification=messaging.Notification(title=title, body=body),
            token=user.device_token,
        )
        messaging.send(message, app=app)
    except Exception:  # noqa: BLE001
        logger.exception("Failed to send push notification to user %s", user.id)
