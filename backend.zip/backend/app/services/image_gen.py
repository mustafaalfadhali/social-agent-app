"""
AI poster/image generation via Cloudflare Workers AI (free tier: 10,000
"neurons"/day, no billing card required - see
https://developers.cloudflare.com/workers-ai/platform/pricing/).

Uses the FLUX.1-schnell text-to-image model, which is fast and decent for
marketing/poster-style graphics. Swap MODEL below to try a different
Workers AI model if you want higher quality at the cost of speed (e.g.
"@cf/stabilityai/stable-diffusion-xl-base-1.0").

Cloudflare's response shape differs by model: some return the image as raw
bytes with an image/* content-type, others wrap it in JSON as
{"result": {"image": "<base64>"}}. We handle both so a model swap doesn't
silently break this.
"""
import base64

import httpx
from fastapi import HTTPException

from ..config import settings

MODEL = "@cf/black-forest-labs/flux-1-schnell"


async def generate_image_bytes(prompt: str) -> bytes:
    """Calls Cloudflare Workers AI and returns raw PNG/JPEG bytes."""
    if not settings.cloudflare_account_id or not settings.cloudflare_api_token:
        raise HTTPException(
            status_code=500,
            detail="CLOUDFLARE_ACCOUNT_ID / CLOUDFLARE_API_TOKEN not set on the server (.env)",
        )

    url = (
        f"https://api.cloudflare.com/client/v4/accounts/"
        f"{settings.cloudflare_account_id}/ai/run/{MODEL}"
    )
    headers = {"Authorization": f"Bearer {settings.cloudflare_api_token}"}

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(url, headers=headers, json={"prompt": prompt})

    if resp.status_code >= 400:
        raise HTTPException(
            status_code=502,
            detail=f"Cloudflare Workers AI error ({resp.status_code}): {resp.text[:300]}",
        )

    content_type = resp.headers.get("content-type", "")
    if content_type.startswith("image/"):
        return resp.content

    data = resp.json()
    if not data.get("success", True) and "result" not in data:
        raise HTTPException(
            status_code=502,
            detail=f"Cloudflare Workers AI returned an error: {data}",
        )
    b64_image = data.get("result", {}).get("image")
    if not b64_image:
        raise HTTPException(
            status_code=502,
            detail=f"Unexpected Cloudflare Workers AI response shape: {data}",
        )
    return base64.b64decode(b64_image)
