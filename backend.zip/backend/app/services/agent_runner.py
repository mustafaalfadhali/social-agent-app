"""
The actual agent loop: Instructions + Tools + a loop that runs until an
exit condition, per the "single-agent system" pattern (Input -> Agent ->
Output, with the agent repeatedly calling tools until it's done). This is
the piece that makes the app more than "an app with some AI features in
it" - Claude itself decides which accounts to look at, whether posting is
warranted, what to write, and when to stop; nothing here is a fixed,
hand-coded sequence of steps.

Hard safety rule baked into both the system prompt AND the tool design:
the agent can only ever create a *draft* (create_draft_post ->
status="pending_approval"). Publishing requires a separate, explicit human
action via POST /posts/{id}/approve. Never remove that separation without
deliberately deciding you want a fully autonomous (auto-publishing) agent -
that's a real product/safety decision, not just a code change.
"""
from sqlalchemy.orm import Session

from ..config import settings
from ..models import User, AgentRun
from .agent_tools import TOOLS, execute_tool
from .claude_client import get_client
from .notifications import notify_user

MAX_DRAFTS_PER_RUN = 3

AGENT_SYSTEM_PROMPT = f"""You are an autonomous social media manager agent \
working for a small business owner. Each run, your job is to:

1. Call list_connected_accounts to see what you're managing.
2. Call get_recent_feedback to see how your last several drafts were \
received - approved & published, or rejected (and why, if the human said). \
Treat this as the most important signal you have: don't propose a content \
type or angle that was recently rejected unless you have a genuinely new \
reason to think it'd land differently now, and lean toward angles similar \
to what got published without complaint.
3. Call get_recent_performance to see how your past PUBLISHED posts \
actually did (likes/comments/engagement), not just whether they were \
approved. Being approved and actually performing well are different \
things - a topic that keeps getting approved but consistently \
underperforms is a signal to try something else, even without an explicit \
rejection.
4. For each account (or at least the one(s) most likely to need attention), \
call get_account_analysis to understand what's working and what isn't. If \
search_trends is available and a timely/current-events angle could make \
the content noticeably more relevant, use it - but don't force a trend \
connection that isn't a natural fit. You also have browse_webpage, which \
opens a real public webpage and reads it (e.g. a Google Business reviews \
page, a competitor's site) - use it when a specific external page would \
genuinely inform your decision, not as a routine step every run.
5. Decide whether posting new content right now is actually warranted - do \
NOT create a draft just to have something to show. Only proceed if the \
analysis (and the feedback/performance history) genuinely suggests a real \
opportunity.
6. If you decide to proceed, this run can produce UP TO {MAX_DRAFTS_PER_RUN} \
drafts (not exactly one) - this account is meant to post a small batch every \
couple of days, not a single item. For each draft: call \
generate_post_content for a distinct topic/angle informed by everything \
above, then call create_draft_post with clear reasoning that explicitly \
references what you learned from past feedback and performance if it \
influenced your choice. Don't pad the batch with weak, similar, or \
repetitive ideas just to hit the cap - draft 1, 2, or {MAX_DRAFTS_PER_RUN}, \
whatever the real opportunity supports, and each draft should stand on its \
own as something worth publishing.
7. You can NEVER publish directly - create_draft_post always requires a \
separate human approval step afterward, every single time, for every \
draft. This is a hard rule, not a suggestion, and there is no tool \
available to you that publishes directly.
8. Call finish with a short, human-readable summary of what you looked at \
and what you decided (including how many drafts you made and why that \
number), once you're done - whether or not you created any drafts.

Be efficient: don't call the same tool twice with the same arguments, and \
don't analyze every single account if the first one already gives you a \
clear, strong opportunity. Write your summary and any draft caption in the \
same language the account/business content is normally in (default to \
Arabic if unclear)."""

MAX_TURNS = 12  # raised from 8 - drafting up to MAX_DRAFTS_PER_RUN posts takes more tool-call turns than the old single-draft flow


async def run_agent_cycle(user: User, db: Session) -> dict:
    client = get_client()
    messages = [
        {
            "role": "user",
            "content": "Run your review now and take any action you judge appropriate.",
        }
    ]
    created_draft_ids: list[int] = []
    tool_log: list[dict] = []

    for turn in range(MAX_TURNS):
        response = client.messages.create(
            model=settings.claude_model,
            max_tokens=1500,
            system=AGENT_SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages,
        )

        tool_uses = [b for b in response.content if b.type == "tool_use"]
        text_blocks = [b.text for b in response.content if b.type == "text"]

        if not tool_uses:
            # Safety net: the model stopped without explicitly calling
            # `finish`. Not the expected path, but don't loop forever.
            return {
                "summary": " ".join(text_blocks) or "Agent stopped without a summary.",
                "created_draft_ids": created_draft_ids,
                "tool_log": tool_log,
                "turns": turn + 1,
            }

        assistant_content = []
        for block in response.content:
            if block.type == "text":
                assistant_content.append({"type": "text", "text": block.text})
            elif block.type == "tool_use":
                assistant_content.append(
                    {
                        "type": "tool_use",
                        "id": block.id,
                        "name": block.name,
                        "input": block.input,
                    }
                )
        messages.append({"role": "assistant", "content": assistant_content})

        tool_result_blocks = []
        finished_summary = None
        for tool_use in tool_uses:
            if tool_use.name == "finish":
                finished_summary = tool_use.input.get("summary", "")
                result = {"ok": True}
            else:
                result = await execute_tool(
                    tool_use.name, tool_use.input, user, db, created_draft_ids
                )
            tool_log.append(
                {"tool": tool_use.name, "input": tool_use.input, "result": result}
            )
            tool_result_blocks.append(
                {
                    "type": "tool_result",
                    "tool_use_id": tool_use.id,
                    "content": _to_text(result),
                }
            )

        if finished_summary is not None:
            return {
                "summary": finished_summary,
                "created_draft_ids": created_draft_ids,
                "tool_log": tool_log,
                "turns": turn + 1,
            }

        messages.append({"role": "user", "content": tool_result_blocks})

    return {
        "summary": "Agent stopped after reaching the max turn limit without calling finish.",
        "created_draft_ids": created_draft_ids,
        "tool_log": tool_log,
        "turns": MAX_TURNS,
    }


def _to_text(result: dict) -> str:
    import json

    return json.dumps(result, default=str, ensure_ascii=False)


async def execute_and_log_agent_run(
    user: User, db: Session, triggered_by: str = "manual"
) -> dict:
    """Runs one cycle and persists an AgentRun record so it shows up in the
    Command Center's activity feed regardless of whether a human tapped
    "Run agent now" or the scheduler fired it unattended."""
    result = await run_agent_cycle(user, db)

    run = AgentRun(
        owner_id=user.id,
        triggered_by=triggered_by,
        summary=result.get("summary", ""),
        turns=result.get("turns", 0),
        created_draft_ids=",".join(
            str(i) for i in result.get("created_draft_ids", [])
        ),
    )
    db.add(run)
    db.commit()
    db.refresh(run)

    draft_count = len(result.get("created_draft_ids", []))
    if draft_count > 0:
        # Best-effort - notify_user() never raises, so this can't break an
        # otherwise-successful run.
        notify_user(
            user,
            title="Your AI agent has a draft ready",
            body=result.get("summary", "")[:180] or "Tap to review.",
        )

    result["run_id"] = run.id
    result["triggered_by"] = triggered_by
    return result
