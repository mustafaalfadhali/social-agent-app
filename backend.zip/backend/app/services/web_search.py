"""
Live web search for the agent's `search_trends` tool, backed by the Brave
Search API. This is what lets the agent tie a draft to something actually
happening right now instead of only reasoning from static page metrics.

Same "graceful no-op" pattern used everywhere else an external service is
optional (Meta metrics, push notifications): if BRAVE_SEARCH_API_KEY isn't
set, the tool still exists and is still offered to Claude, but calling it
just returns `{"available": False, ...}` instead of raising - the agent's
system prompt already tells it this tool may not be available and to not
force a trend connection that isn't a natural fit.
"""
import httpx

from ..config import settings

BRAVE_SEARCH_URL = "https://api.search.brave.com/res/v1/web/search"


async def search_trends(query: str, count: int = 5) -> dict:
    if not settings.brave_search_api_key:
        return {
            "available": False,
            "reason": (
                "Live trend search isn't configured on this server "
                "(BRAVE_SEARCH_API_KEY not set) - proceed using only the "
                "account analysis, feedback, and performance data you "
                "already have."
            ),
        }

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(
                BRAVE_SEARCH_URL,
                params={"q": query, "count": count},
                headers={
                    "Accept": "application/json",
                    "X-Subscription-Token": settings.brave_search_api_key,
                },
            )
            resp.raise_for_status()
            data = resp.json()
    except Exception as exc:
        return {
            "available": False,
            "reason": f"Search failed ({exc}) - proceed without trend data.",
        }

    results = []
    for item in (data.get("web", {}) or {}).get("results", [])[:count]:
        results.append(
            {
                "title": item.get("title", ""),
                "description": item.get("description", ""),
                "url": item.get("url", ""),
                "age": item.get("age"),
            }
        )

    return {"available": True, "query": query, "results": results}
