from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    secret_key: str = "dev-secret-change-me"
    access_token_expire_minutes: int = 1440
    database_url: str = "sqlite:///./app.db"

    anthropic_api_key: str = ""
    claude_model: str = "claude-sonnet-4-5"

    meta_app_id: str = ""
    meta_app_secret: str = ""
    meta_redirect_uri: str = "http://localhost:8000/meta/callback"
    meta_graph_api_version: str = "v20.0"
    # Facebook Login for Business "Configuration ID" (from the Meta Developer
    # console: App -> Facebook Login for Business -> Configurations). Newer
    # Meta apps that request Page/Instagram permissions (pages_show_list,
    # pages_manage_posts, instagram_basic, instagram_content_publish, etc.)
    # must use this config_id-based OAuth flow instead of a raw `scope` list
    # - the classic scope-based dialog fails with a generic
    # "Sorry, something went wrong" error for these permissions now.
    meta_config_id: str = ""

    # Autonomous agent scheduling - runs the agent once per user, on this
    # cron schedule, with no one having to tap "Run agent now". See
    # app/services/scheduler.py.
    agent_schedule_enabled: bool = True
    agent_schedule_cron: str = "0 9 * * *"  # daily at 09:00 UTC by default

    # How long to wait after a post goes live before checking its
    # performance (gives it time to actually accumulate engagement), and
    # how often the check itself runs.
    performance_check_enabled: bool = True
    performance_check_cron: str = "0 */6 * * *"  # every 6 hours
    performance_check_min_age_hours: int = 48

    # Push notifications (Firebase Cloud Messaging) - path to a Firebase
    # service account JSON file. Leave blank to disable pushes entirely;
    # everything else in the app works fine without this set. See
    # app/services/notifications.py for setup steps.
    firebase_service_account_path: str = ""

    # Brave Search API key for the agent's search_trends tool. Leave blank
    # to disable - the tool then tells the agent it's unavailable instead
    # of erroring. See app/services/web_search.py.
    brave_search_api_key: str = ""

    # Cloudflare Workers AI - free tier (10,000 "neurons"/day, no card
    # needed) used for AI poster/image generation (FLUX.1-schnell model).
    # Get both values from the Cloudflare dashboard: Account ID is on the
    # right sidebar of any dashboard page; the API token is created under
    # My Profile -> API Tokens -> Create Token -> "Workers AI" template.
    # See app/services/image_gen.py. Leave blank to disable the
    # "Generate with AI" image button - the rest of the app is unaffected.
    cloudflare_account_id: str = ""
    cloudflare_api_token: str = ""


settings = Settings()
