from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from ..database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=True)
    # FCM registration token for push notifications (e.g. "you have a new
    # draft to review"). One per user for simplicity - a real multi-device
    # setup would use a separate device_tokens table.
    device_token = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    social_accounts = relationship("SocialAccount", back_populates="owner", cascade="all, delete-orphan")
    posts = relationship("Post", back_populates="owner", cascade="all, delete-orphan")
