from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from ..database import Base


class Post(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    caption = Column(Text, nullable=False)
    media_url = Column(String, nullable=True)
    target_platforms = Column(String, nullable=False)  # comma-separated: "facebook_page,instagram_business"
    status = Column(String, default="draft")  # draft | scheduled | pending_approval | published | failed | rejected
    scheduled_for = Column(DateTime(timezone=True), nullable=True)
    published_at = Column(DateTime(timezone=True), nullable=True)
    result_log = Column(Text, nullable=True)

    # Human feedback, captured on reject (optional) - what the feedback loop
    # (get_recent_feedback tool) reads so the agent can learn what landed
    # and what didn't, instead of repeating the same misses.
    feedback = Column(Text, nullable=True)

    # {"facebook_page": "<graph id>", "instagram_business": "<media id>"} -
    # captured at publish time so performance can be looked up afterward.
    platform_post_ids = Column(Text, nullable=True)
    performance_json = Column(Text, nullable=True)
    performance_checked_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    owner = relationship("User", back_populates="posts")
