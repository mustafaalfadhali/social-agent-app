from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime
from sqlalchemy.sql import func

from ..database import Base


class AgentRun(Base):
    """One completed agent cycle - manual (button tap) or scheduled (cron).
    This is what the Command Center's activity feed reads from, and what
    makes "the agent ran while I wasn't looking" visible instead of silent.
    """

    __tablename__ = "agent_runs"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    triggered_by = Column(String, default="manual")  # "manual" | "scheduled"
    summary = Column(Text, nullable=False)
    turns = Column(Integer, default=0)
    created_draft_ids = Column(String, nullable=True)  # comma-separated post ids

    created_at = Column(DateTime(timezone=True), server_default=func.now())
