"""
A code change the self-development agent proposed for its OWN backend
source code, sitting in "pending_approval" until a human explicitly
approves or rejects it - the exact same human-in-the-loop pattern as
Post/create_draft_post (services/agent_tools.py), just applied to the
agent's own code instead of social content. The agent can NEVER write to
disk on its own; approve_code_proposal (routers/self_dev.py) is the only
path that ever touches a real file.
"""
from sqlalchemy import Column, DateTime, Integer, String, Text
from sqlalchemy.sql import func

from ..database import Base


class CodeProposal(Base):
    __tablename__ = "code_proposals"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, index=True, nullable=False)

    # Path relative to backend/, e.g. "app/services/web_search.py" - always
    # validated against an allowlist before anything is ever written (see
    # self_dev_tools.ALLOWED_ROOTS / _validate_path).
    file_path = Column(String, nullable=False)

    reasoning = Column(Text, nullable=False)  # shown to the human reviewer
    old_content = Column(Text, nullable=True)  # snapshot at proposal time - lets a human see the diff
    new_content = Column(Text, nullable=False)

    # pending_approval | applied | rejected | failed
    # "failed" = approved, but the safety check (syntax validation) caught a
    # problem before anything was written - see routers/self_dev.py.
    status = Column(String, default="pending_approval")
    error_log = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
