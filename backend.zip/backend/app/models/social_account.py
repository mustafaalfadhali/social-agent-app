from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from ..database import Base


class SocialAccount(Base):
    """A connected Meta (Facebook Page / Instagram Business) account."""

    __tablename__ = "social_accounts"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    platform = Column(String, nullable=False)  # "facebook_page" | "instagram_business"
    platform_account_id = Column(String, nullable=False)  # Page ID / IG Business Account ID
    display_name = Column(String, nullable=True)

    # In production: encrypt this at rest (e.g. Fernet) - stored plain here for clarity only.
    access_token = Column(String, nullable=False)
    token_expires_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    owner = relationship("User", back_populates="social_accounts")
