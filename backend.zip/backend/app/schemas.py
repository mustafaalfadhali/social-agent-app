from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, EmailStr, Field


# ---------- Auth ----------
class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    full_name: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    email: EmailStr
    full_name: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- Social accounts ----------
class SocialAccountOut(BaseModel):
    id: int
    platform: str
    platform_account_id: str
    display_name: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Analysis ----------
class AnalysisRequest(BaseModel):
    social_account_id: int


class AnalysisResult(BaseModel):
    social_account_id: int
    platform: str
    summary: str
    strengths: List[str]
    recommendations: List[str]
    best_posting_times: List[str]


# ---------- Posts / publishing ----------
class PostCreate(BaseModel):
    caption: str
    media_url: Optional[str] = None
    target_platforms: List[str]  # e.g. ["facebook_page", "instagram_business"]
    scheduled_for: Optional[datetime] = None


class PostOut(BaseModel):
    id: int
    caption: str
    media_url: Optional[str] = None
    target_platforms: str
    status: str
    scheduled_for: Optional[datetime] = None
    published_at: Optional[datetime] = None
    result_log: Optional[str] = None
    feedback: Optional[str] = None
    performance_json: Optional[str] = None
    performance_checked_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class RejectRequest(BaseModel):
    reason: Optional[str] = None


# ---------- Push notifications ----------
class DeviceTokenUpdate(BaseModel):
    token: str
