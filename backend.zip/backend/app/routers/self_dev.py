"""
The self-development agent's API surface: trigger a review cycle, list what
it proposed, and the ONLY two endpoints that can ever turn a proposal into
a real file change - approve (human-triggered only) and reject.

Mirrors routers/agent.py's shape closely - background-task trigger (see
that file for why: a multi-Claude-call cycle can easily exceed Cloudflare's
~100s edge timeout) plus the same human-approval gate pattern as
routers/publish.py's approve_post.
"""
import asyncio
import os

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from ..config import settings
from ..database import SessionLocal, get_db
from ..models import CodeProposal, User
from ..security import get_current_user
from ..services.notifications import notify_user
from ..services.self_dev_runner import run_self_dev_cycle
from ..services.self_dev_tools import BACKEND_ROOT, validate_own_source_path

router = APIRouter(prefix="/self-dev", tags=["self-dev"])


async def _run_self_dev_in_background(user_id: int) -> None:
    """Own DB session, independent of the triggering request - same reason
    as agent.py's _run_agent_in_background: this can take a while and must
    never be tied to a request Cloudflare might time out."""
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if user is None:
            return
        result = await run_self_dev_cycle(user, db)
        if result.get("proposal_ids"):
            notify_user(
                user,
                title="Your AI agent proposed a code change",
                body=result.get("summary", "")[:180] or "Tap to review.",
            )
    finally:
        db.close()


@router.post("/run")
async def run_self_dev(
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Kicks off one self-review cycle in the background and returns
    immediately - see _run_self_dev_in_background for why. Poll GET
    /self-dev/proposals (or wait for the push notification) for the result."""
    if not settings.anthropic_api_key:
        raise HTTPException(
            status_code=500,
            detail="ANTHROPIC_API_KEY is not set on the server (.env)",
        )
    background_tasks.add_task(_run_self_dev_in_background, current_user.id)
    return {"status": "started"}


@router.get("/proposals")
def list_proposals(
    status: str | None = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(CodeProposal).filter(CodeProposal.owner_id == current_user.id)
    if status:
        query = query.filter(CodeProposal.status == status)
    proposals = query.order_by(CodeProposal.created_at.desc()).all()
    return [
        {
            "id": p.id,
            "file_path": p.file_path,
            "reasoning": p.reasoning,
            "old_content": p.old_content,
            "new_content": p.new_content,
            "status": p.status,
            "error_log": p.error_log,
            "created_at": p.created_at,
        }
        for p in proposals
    ]


def _restart_process() -> None:
    """The container is run with --restart unless-stopped (see the
    deployment docs), so killing this process makes Docker bring it right
    back up - and because this is a plain container restart (not a
    recreate), the file we just wrote to the container's own writable
    layer is still there when it comes back. This is the only way a
    Python process can pick up a change to its own already-imported source
    without a human re-running docker build."""
    os._exit(0)


@router.post("/proposals/{proposal_id}/approve")
async def approve_proposal(
    proposal_id: int,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    proposal = (
        db.query(CodeProposal)
        .filter(CodeProposal.id == proposal_id, CodeProposal.owner_id == current_user.id)
        .first()
    )
    if not proposal:
        raise HTTPException(status_code=404, detail="Proposal not found")
    if proposal.status != "pending_approval":
        raise HTTPException(
            status_code=400,
            detail=f"Proposal is not pending approval (status={proposal.status})",
        )

    try:
        target_path = validate_own_source_path(proposal.file_path)
    except ValueError as exc:
        proposal.status = "failed"
        proposal.error_log = f"path validation failed at approval time: {exc}"
        db.commit()
        raise HTTPException(status_code=400, detail=str(exc))

    # Safety net: catch a broken proposal (syntax error) BEFORE writing it
    # or restarting the process - never let a bad approval crash-loop the
    # container. This checks syntax only, not correctness; a well-formed
    # but logically wrong change can still slip through, same as any code
    # review can miss a bug.
    try:
        compile(proposal.new_content, str(target_path), "exec")
    except SyntaxError as exc:
        proposal.status = "failed"
        proposal.error_log = f"syntax check failed - nothing was written: {exc}"
        db.commit()
        raise HTTPException(
            status_code=400,
            detail=f"Rejected automatically - the proposed code has a syntax error: {exc}",
        )

    target_path.write_text(proposal.new_content, encoding="utf-8")
    proposal.status = "applied"
    db.commit()

    # Restart AFTER this response is safely on its way back to the client -
    # BackgroundTasks run once the response has been sent.
    async def _delayed_restart():
        await asyncio.sleep(1)
        _restart_process()

    background_tasks.add_task(_delayed_restart)

    return {
        "status": "applied",
        "file_path": proposal.file_path,
        "note": "Backend is restarting now to load the change - it will be back within a few seconds.",
    }


@router.post("/proposals/{proposal_id}/reject")
def reject_proposal(
    proposal_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    proposal = (
        db.query(CodeProposal)
        .filter(CodeProposal.id == proposal_id, CodeProposal.owner_id == current_user.id)
        .first()
    )
    if not proposal:
        raise HTTPException(status_code=404, detail="Proposal not found")
    proposal.status = "rejected"
    db.commit()
    return {"status": "rejected"}
