"""AI-assisted post/article writing, powered by Claude."""
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..config import settings
from ..models import User
from ..security import get_current_user
from ..services.claude_client import generate_post_variations
from ..services.image_gen import generate_image_bytes

router = APIRouter(prefix="/content", tags=["content"])

# Same directory/serving scheme as routers/media.py (app.mount("/media", ...)
# in main.py) so AI-generated posters are reachable at the same public
# /media/<filename> URL that Meta's Graph API fetches from when publishing.
MEDIA_DIR = Path(__file__).resolve().parent.parent.parent / "media"
MEDIA_DIR.mkdir(exist_ok=True)


class GenerateContentRequest(BaseModel):
    topic: str = Field(min_length=3, description="What the post/article is about")
    platform: str = Field(default="instagram_business")  # instagram_business | facebook_page | article
    tone: str = Field(default="friendly and professional")
    language: str = Field(default="Arabic")


class ContentVariation(BaseModel):
    caption: str
    hashtags: list[str] = []


class GenerateContentResponse(BaseModel):
    variations: list[ContentVariation]


@router.post("/generate-post", response_model=GenerateContentResponse)
async def generate_post(
    payload: GenerateContentRequest,
    current_user: User = Depends(get_current_user),
):
    if not settings.anthropic_api_key:
        raise HTTPException(
            status_code=500,
            detail="ANTHROPIC_API_KEY is not set on the server (.env)",
        )

    data = await generate_post_variations(
        topic=payload.topic,
        platform=payload.platform,
        tone=payload.tone,
        language=payload.language,
    )
    return GenerateContentResponse(**data)


class GenerateImageRequest(BaseModel):
    prompt: str = Field(min_length=3, description="What the poster/image should show")


class GenerateImageResponse(BaseModel):
    url: str


@router.post("/generate-image", response_model=GenerateImageResponse)
async def generate_image(
    payload: GenerateImageRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
):
    """
    Generates a poster/marketing image via Cloudflare Workers AI (free
    tier - see services/image_gen.py) and saves it to the same local
    media store routers/media.py uses, so it gets a public URL Meta's
    Graph API can fetch when publishing (image_url on POST /posts).
    """
    image_bytes = await generate_image_bytes(payload.prompt)

    filename = f"{current_user.id}-{uuid.uuid4().hex}.png"
    (MEDIA_DIR / filename).write_bytes(image_bytes)

    base = settings.public_base_url or str(request.base_url).rstrip("/")
    public_url = f"{base.rstrip('/')}/media/{filename}"
    return GenerateImageResponse(url=public_url)
