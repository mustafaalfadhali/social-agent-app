"""AI-assisted post/article writing, powered by Claude."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..config import settings
from ..models import User
from ..security import get_current_user
from ..services.claude_client import generate_post_variations

router = APIRouter(prefix="/content", tags=["content"])


class GenerateContentRequest(BaseModel):
    topic: str = Field(min_length=3, description="What the post/article is about")
    platform: str = Field(default="instagram_business")  # instagram_business | facebook_page | article
    tone: str = Field(default="friendly and professional")
    language: str = Field(default="Arabic")


class ContentVariation(BaseModel):
    caption: str
    hashtags: list[str] = []


class GenerateContentResponse(BaseModel):
    variations: list[ContentVariation]


@router.post("/generate-post", response_model=GenerateContentResponse)
def generate_post(
    payload: GenerateContentRequest,
    current_user: User = Depends(get_current_user),
):
    if not settings.anthropic_api_key:
        raise HTTPException(
            status_code=500,
            detail="ANTHROPIC_API_KEY is not set on the server (.env)",
        )

    data = generate_post_variations(
        topic=payload.topic,
        platform=payload.platform,
        tone=payload.tone,
        language=payload.language,
    )
    return GenerateContentResponse(**data)
