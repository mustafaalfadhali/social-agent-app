"""
Meta (Facebook Pages / Instagram Business) OAuth connection flow.

IMPORTANT — read before wiring this to production:
Publishing on behalf of *other people's* Pages/Instagram accounts requires
your Meta App to pass App Review for these permissions:
  - pages_show_list, pages_read_engagement, pages_manage_posts
  - instagram_basic, instagram_content_publish
Until App Review is approved, this flow only works for accounts you add
as "Testers" / "Admins" on your app in the Meta Developer console
(Settings -> Roles). That's expected during development - it's not a bug.
"""
from urllib.parse import urlencode

import httpx
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models import User, SocialAccount
from ..schemas import SocialAccountOut
from ..security import get_current_user

router = APIRouter(prefix="/meta", tags=["meta"])

GRAPH_BASE = f"https://graph.facebook.com/{settings.meta_graph_api_version}"
DIALOG_BASE = f"https://www.facebook.com/{settings.meta_graph_api_version}/dialog/oauth"

SCOPES = [
    "pages_show_list",
    "pages_read_engagement",
    "pages_manage_posts",
    "instagram_basic",
    "instagram_content_publish",
]


@router.get("/connect-url")
def get_connect_url(current_user: User = Depends(get_current_user)):
    """
    Returns the Meta OAuth dialog URL. The mobile app opens this in a
    webview; after the user approves, Meta redirects to META_REDIRECT_URI
    with a `code` param, which the app forwards to POST /meta/callback.
    We encode the user's id in `state` so we know who to attach accounts to.
    """
    params = {
        "client_id": settings.meta_app_id,
        "redirect_uri": settings.meta_redirect_uri,
        "state": str(current_user.id),
        "scope": ",".join(SCOPES),
        "response_type": "code",
    }
    return {"url": f"{DIALOG_BASE}?{urlencode(params)}"}


@router.post("/callback", response_model=list[SocialAccountOut])
async def meta_callback(code: str, state: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == int(state)).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found for state")

    async with httpx.AsyncClient() as client:
        # 1. Exchange code -> short-lived user access token
        token_resp = await client.get(
            f"{GRAPH_BASE}/oauth/access_token",
            params={
                "client_id": settings.meta_app_id,
                "client_secret": settings.meta_app_secret,
                "redirect_uri": settings.meta_redirect_uri,
                "code": code,
            },
        )
        token_resp.raise_for_status()
        user_token = token_resp.json()["access_token"]

        # 2. Exchange for a long-lived token (~60 days)
        long_lived_resp = await client.get(
            f"{GRAPH_BASE}/oauth/access_token",
            params={
                "grant_type": "fb_exchange_token",
                "client_id": settings.meta_app_id,
                "client_secret": settings.meta_app_secret,
                "fb_exchange_token": user_token,
            },
        )
        long_lived_resp.raise_for_status()
        long_lived_token = long_lived_resp.json()["access_token"]

        # 3. List the Pages this user manages (each Page has its own token)
        pages_resp = await client.get(
            f"{GRAPH_BASE}/me/accounts",
            params={"access_token": long_lived_token},
        )
        pages_resp.raise_for_status()
        pages = pages_resp.json().get("data", [])

    created: list[SocialAccount] = []
    for page in pages:
        page_account = SocialAccount(
            owner_id=user.id,
            platform="facebook_page",
            platform_account_id=page["id"],
            display_name=page.get("name"),
            access_token=page["access_token"],
        )
        db.add(page_account)
        created.append(page_account)

        # Look up a linked Instagram Business account, if any
        async with httpx.AsyncClient() as client:
            ig_resp = await client.get(
                f"{GRAPH_BASE}/{page['id']}",
                params={
                    "fields": "instagram_business_account",
                    "access_token": page["access_token"],
                },
            )
        ig_data = ig_resp.json().get("instagram_business_account")
        if ig_data:
            ig_account = SocialAccount(
                owner_id=user.id,
                platform="instagram_business",
                platform_account_id=ig_data["id"],
                display_name=f"{page.get('name')} (Instagram)",
                access_token=page["access_token"],
            )
            db.add(ig_account)
            created.append(ig_account)

    db.commit()
    for acc in created:
        db.refresh(acc)
    return created


@router.get("", response_model=list[SocialAccountOut])
def list_connected_accounts(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return (
        db.query(SocialAccount)
        .filter(SocialAccount.owner_id == current_user.id)
        .all()
    )
