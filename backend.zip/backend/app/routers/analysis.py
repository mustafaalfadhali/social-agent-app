from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models import User, SocialAccount
from ..schemas import AnalysisRequest, AnalysisResult
from ..security import get_current_user
from ..services.claude_client import analyze_page_metrics
from ..services.meta_insights import get_real_metrics, get_mock_metrics

router = APIRouter(prefix="/analysis", tags=["analysis"])


@router.post("", response_model=AnalysisResult)
async def analyze_account(
    payload: AnalysisRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    account = (
        db.query(SocialAccount)
        .filter(
            SocialAccount.id == payload.social_account_id,
            SocialAccount.owner_id == current_user.id,
        )
        .first()
    )
    if not account:
        raise HTTPException(status_code=404, detail="Social account not found")

    if not settings.anthropic_api_key:
        raise HTTPException(
            status_code=500,
            detail="ANTHROPIC_API_KEY is not set on the server (.env)",
        )

    # Use real Graph API insights once App Review is approved; until then
    # (or if the call fails, e.g. permissions not granted yet) fall back to
    # representative mock data so the analysis pipeline is still demoable.
    try:
        metrics = await get_real_metrics(account)
    except Exception:
        metrics = get_mock_metrics(account.platform)

    result = analyze_page_metrics(account.platform, metrics)

    return AnalysisResult(
        social_account_id=account.id,
        platform=account.platform,
        summary=result.get("summary", ""),
        strengths=result.get("strengths", []),
        recommendations=result.get("recommendations", []),
        best_posting_times=result.get("best_posting_times", []),
    )
