"""
Media upload for posters/images designed in the app.

Meta's Graph API needs a *publicly reachable* image_url to publish a photo
post (it fetches the image itself - it can't take raw bytes from the
mobile app directly for Page/Instagram photo posts). So the flow is:
design in-app -> export PNG -> upload here -> get back a public URL ->
that URL is what gets sent to /posts as media_url.

This stores files on local disk and serves them from /media/<filename>,
which is fine for local development. For production, swap
`save_upload()` for an S3/Cloud Storage upload and return that URL instead
- and make sure your backend itself is deployed somewhere with a real
public HTTPS domain (Graph API will not fetch from a local machine or
plain localhost).
"""
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile

from ..models import User
from ..security import get_current_user

router = APIRouter(prefix="/media", tags=["media"])

MEDIA_DIR = Path(__file__).resolve().parent.parent.parent / "media"
MEDIA_DIR.mkdir(exist_ok=True)

ALLOWED_CONTENT_TYPES = {"image/png", "image/jpeg", "image/webp"}
MAX_UPLOAD_BYTES = 15 * 1024 * 1024  # 15 MB


@router.post("/upload")
async def upload_media(
    request: Request,
    file: UploadFile,
    current_user: User = Depends(get_current_user),
):
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported content type: {file.content_type}",
        )

    contents = await file.read()
    if len(contents) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=400, detail="File too large (max 15MB)")

    ext = {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp"}[file.content_type]
    filename = f"{current_user.id}-{uuid.uuid4().hex}.{ext}"
    (MEDIA_DIR / filename).write_bytes(contents)

    public_url = f"{request.base_url}media/{filename}"
    return {"url": public_url}
