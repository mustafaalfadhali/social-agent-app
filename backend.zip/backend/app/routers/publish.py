import json
from datetime import datetime, timezone

import httpx
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models import User, Post, SocialAccount
from ..schemas import PostCreate, PostOut, RejectRequest
from ..security import get_current_user

router = APIRouter(prefix="/posts", tags=["posts"])

GRAPH_BASE = f"https://graph.facebook.com/{settings.meta_graph_api_version}"


@router.post("", response_model=PostOut)
async def create_and_publish_post(
    payload: PostCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    post = Post(
        owner_id=current_user.id,
        caption=payload.caption,
        media_url=payload.media_url,
        target_platforms=",".join(payload.target_platforms),
        scheduled_for=payload.scheduled_for,
        status="scheduled" if payload.scheduled_for else "draft",
    )
    db.add(post)
    db.commit()
    db.refresh(post)

    # If no schedule was given, publish immediately.
    if not payload.scheduled_for:
        await _publish_now(post, payload.target_platforms, current_user, db)

    return post


async def _publish_now(
    post: Post, platforms: list[str], user: User, db: Session
):
    accounts = (
        db.query(SocialAccount)
        .filter(
            SocialAccount.owner_id == user.id,
            SocialAccount.platform.in_(platforms),
        )
        .all()
    )

    logs = []
    all_ok = True
    platform_post_ids: dict[str, str] = {}
    async with httpx.AsyncClient() as client:
        for account in accounts:
            try:
                if account.platform == "facebook_page":
                    resp = await client.post(
                        f"{GRAPH_BASE}/{account.platform_account_id}/feed",
                        data={
                            "message": post.caption,
                            "access_token": account.access_token,
                            **({"link": post.media_url} if post.media_url else {}),
                        },
                    )
                elif account.platform == "instagram_business":
                    # IG publishing is a 2-step process: create a media
                    # container, then publish it.
                    container = await client.post(
                        f"{GRAPH_BASE}/{account.platform_account_id}/media",
                        data={
                            "caption": post.caption,
                            "image_url": post.media_url,
                            "access_token": account.access_token,
                        },
                    )
                    container.raise_for_status()
                    creation_id = container.json()["id"]
                    resp = await client.post(
                        f"{GRAPH_BASE}/{account.platform_account_id}/media_publish",
                        data={
                            "creation_id": creation_id,
                            "access_token": account.access_token,
                        },
                    )
                else:
                    continue

                resp.raise_for_status()
                resp_json = resp.json()
                if resp_json.get("id"):
                    # Stored so a later job can look up this specific post's
                    # own performance (likes/comments/reach), not just the
                    # page's aggregate metrics. See services/post_performance.py.
                    platform_post_ids[account.platform] = resp_json["id"]
                logs.append(f"{account.platform}:{account.display_name} -> OK ({resp_json})")
            except Exception as exc:  # noqa: BLE001
                all_ok = False
                logs.append(f"{account.platform}:{account.display_name} -> FAILED ({exc})")

    post.status = "published" if all_ok else "failed"
    post.published_at = datetime.now(timezone.utc)
    if platform_post_ids:
        post.platform_post_ids = json.dumps(platform_post_ids)
    publish_log = "\n".join(logs) if logs else "No connected accounts matched target_platforms."
    # Preserve any prior notes (e.g. the agent's reasoning for this draft)
    # instead of overwriting them.
    post.result_log = f"{post.result_log}\n{publish_log}" if post.result_log else publish_log
    db.commit()


@router.get("", response_model=list[PostOut])
def list_posts(
    status: str | None = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(Post).filter(Post.owner_id == current_user.id)
    if status:
        query = query.filter(Post.status == status)
    return query.order_by(Post.created_at.desc()).all()


@router.post("/{post_id}/approve", response_model=PostOut)
async def approve_post(
    post_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Publishes a draft the agent created (or any 'pending_approval' post) -
    this is the human approval gate. Nothing the agent creates goes live
    without this explicit call."""
    post = (
        db.query(Post)
        .filter(Post.id == post_id, Post.owner_id == current_user.id)
        .first()
    )
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.status != "pending_approval":
        raise HTTPException(
            status_code=400,
            detail=f"Post is not pending approval (status={post.status})",
        )

    platforms = [p for p in post.target_platforms.split(",") if p]
    await _publish_now(post, platforms, current_user, db)
    db.refresh(post)
    return post


@router.post("/{post_id}/reject", response_model=PostOut)
def reject_post(
    post_id: int,
    payload: RejectRequest | None = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Rejecting a draft is also how the agent learns - an optional reason
    here is what get_recent_feedback (agent_tools.py) reads on future runs,
    so 'why' matters more than just the reject itself."""
    post = (
        db.query(Post)
        .filter(Post.id == post_id, Post.owner_id == current_user.id)
        .first()
    )
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    post.status = "rejected"
    if payload and payload.reason:
        post.feedback = payload.reason
    db.commit()
    db.refresh(post)
    return post
