from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User
from ..schemas import DeviceTokenUpdate, UserOut
from ..security import get_current_user

router = APIRouter(prefix="/users", tags=["users"])


@router.put("/me/device-token", response_model=UserOut)
def update_device_token(
    payload: DeviceTokenUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Called once after login (see mobile_app's PushNotifications service)
    to register this device for push notifications - e.g. "your agent
    created a draft while you were away." Overwrites any previous token for
    this user (single-device simplification, see the model comment)."""
    current_user.device_token = payload.token
    db.commit()
    db.refresh(current_user)
    return current_user
