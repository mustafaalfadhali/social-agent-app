from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from ..config import settings
from ..database import SessionLocal, get_db
from ..models import User, AgentRun
from ..security import get_current_user
from ..services.agent_runner import execute_and_log_agent_run

router = APIRouter(prefix="/agent", tags=["agent"])


async def _run_agent_in_background(user_id: int) -> None:
    """Runs one full agent cycle with its OWN database session, completely
    independent of the HTTP request that triggered it.

    Why this exists: a full cycle can involve a dozen+ sequential Claude API
    calls (per-account analysis, content generation for up to 3 drafts,
    etc.) plus optionally opening a real webpage via browse_webpage - easily
    over 100 seconds. Cloudflare's edge has a fixed ~100s timeout it will
    not exceed regardless of server config, so a request that *waits* for
    all of that would get killed with a 524 even though the backend was
    working fine - which is exactly what was happening. Returning
    immediately (see run_agent below) and finishing the real work here,
    after the response is already sent, sidesteps that limit entirely.
    """
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if user is None:
            return
        await execute_and_log_agent_run(user, db, triggered_by="manual")
    finally:
        db.close()


@router.post("/run")
async def run_agent(
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Kicks off one autonomous agent cycle for the current user in the
    background and returns immediately - it reviews connected accounts,
    decides on its own whether new content is warranted, and - at most -
    creates up to a few draft posts awaiting approval. Nothing gets
    published from this call. See services/agent_runner.py.

    The client should poll GET /agent/runs (or just wait for the push
    notification) to see the result - this endpoint intentionally does NOT
    wait for the cycle to finish (see _run_agent_in_background for why).
    """
    if not settings.anthropic_api_key:
        raise HTTPException(
            status_code=500,
            detail="ANTHROPIC_API_KEY is not set on the server (.env)",
        )
    background_tasks.add_task(_run_agent_in_background, current_user.id)
    return {"status": "started"}


@router.get("/runs")
def list_agent_runs(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """History feed for the Command Center screen - shows both manual and
    scheduled runs, so a run that fired unattended overnight is still
    visible the next time you open the app."""
    runs = (
        db.query(AgentRun)
        .filter(AgentRun.owner_id == current_user.id)
        .order_by(AgentRun.created_at.desc())
        .limit(30)
        .all()
    )
    return [
        {
            "id": r.id,
            "triggered_by": r.triggered_by,
            "summary": r.summary,
            "turns": r.turns,
            "created_draft_ids": (
                [int(x) for x in r.created_draft_ids.split(",") if x]
                if r.created_draft_ids
                else []
            ),
            "created_at": r.created_at,
        }
        for r in runs
    ]
