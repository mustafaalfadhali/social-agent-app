from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..models import User, AgentRun
from ..security import get_current_user
from ..services.agent_runner import execute_and_log_agent_run

router = APIRouter(prefix="/agent", tags=["agent"])


@router.post("/run")
async def run_agent(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Triggers one autonomous agent cycle for the current user: it reviews
    connected accounts, decides on its own whether new content is
    warranted, and - at most - creates ONE draft post awaiting approval.
    Nothing gets published from this call. See services/agent_runner.py.
    """
    if not settings.anthropic_api_key:
        raise HTTPException(
            status_code=500,
            detail="ANTHROPIC_API_KEY is not set on the server (.env)",
        )
    return await execute_and_log_agent_run(current_user, db, triggered_by="manual")


@router.get("/runs")
def list_agent_runs(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """History feed for the Command Center screen - shows both manual and
    scheduled runs, so a run that fired unattended overnight is still
    visible the next time you open the app."""
    runs = (
        db.query(AgentRun)
        .filter(AgentRun.owner_id == current_user.id)
        .order_by(AgentRun.created_at.desc())
        .limit(30)
        .all()
    )
    return [
        {
            "id": r.id,
            "triggered_by": r.triggered_by,
            "summary": r.summary,
            "turns": r.turns,
            "created_draft_ids": (
                [int(x) for x in r.created_draft_ids.split(",") if x]
                if r.created_draft_ids
                else []
            ),
            "created_at": r.created_at,
        }
        for r in runs
    ]
