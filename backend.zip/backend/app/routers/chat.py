"""
Free-form chat with Claude, powering the mobile app's "Chat" screen - a
direct conversational assistant, separate from the structured content
generation (/content/generate-post) and the autonomous agent (/agent/run).

Stateless on purpose: the client sends the whole transcript each turn and we
don't persist it server-side. Simple to reason about and nothing to migrate/
clean up later; if per-user chat history ever needs to survive an app
reinstall, that's the point to add a ChatMessage model instead.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..config import settings
from ..models import User
from ..security import get_current_user
from ..services.claude_client import chat_reply

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatMessage(BaseModel):
    role: str  # "user" | "assistant"
    content: str


class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1)


class ChatResponse(BaseModel):
    reply: str


@router.post("", response_model=ChatResponse)
def send_chat_message(
    payload: ChatRequest,
    current_user: User = Depends(get_current_user),
):
    if not settings.anthropic_api_key:
        raise HTTPException(
            status_code=500,
            detail="ANTHROPIC_API_KEY is not set on the server (.env)",
        )

    reply = chat_reply([m.model_dump() for m in payload.messages])
    return ChatResponse(reply=reply)
