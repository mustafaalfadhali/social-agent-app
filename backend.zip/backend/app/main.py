from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .database import Base, engine
from .routers import auth, meta, analysis, publish, content, media, agent, users, chat
from .services.scheduler import start_scheduler, stop_scheduler

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Social Agent API",
    description="Backend for the AI-powered social media manager app (auth, "
    "Meta OAuth, Claude-powered page analysis, AI content generation, "
    "poster uploads, the autonomous agent + its scheduler, publishing).",
    version="0.1.0",
)


@app.on_event("startup")
def _on_startup():
    start_scheduler()


@app.on_event("shutdown")
def _on_shutdown():
    stop_scheduler()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this to your app's origin in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(meta.router)
app.include_router(analysis.router)
app.include_router(publish.router)
app.include_router(content.router)
app.include_router(media.router)
app.include_router(agent.router)
app.include_router(users.router)
app.include_router(chat.router)

media_dir = Path(__file__).resolve().parent.parent / "media"
media_dir.mkdir(exist_ok=True)
app.mount("/media", StaticFiles(directory=str(media_dir)), name="media")


@app.get("/health")
def health():
    return {"status": "ok"}
